import { useState, useEffect, useRef } from 'react';
import { Tale, Task, StudentAnswers, VocabWord } from '../types';
import { 
  Check, 
  X, 
  ArrowLeft, 
  ArrowRight, 
  HelpCircle, 
  Volume2, 
  BookOpen, 
  Sparkles, 
  ArrowUp, 
  ArrowDown, 
  Lock,
  BookMarked
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SplitReaderProps {
  tale: Tale;
  task: Task;
  taskIndex: number;
  totalTaskCount: number;
  tempAnswers: StudentAnswers;
  onAnswerChange: (taskId: string, answer: any) => void;
  onPrevTask: () => void;
  onNextTask: () => void;
  onCheckAnswer: (taskId: string) => void;
  checkedTasks: { [taskId: string]: boolean };
  onCompletePhase: () => void;
}

export default function SplitReader({
  tale,
  task,
  taskIndex,
  totalTaskCount,
  tempAnswers,
  onAnswerChange,
  onPrevTask,
  onNextTask,
  onCheckAnswer,
  checkedTasks,
  onCompletePhase,
}: SplitReaderProps) {
  const [selectedVocab, setSelectedVocab] = useState<typeof tale.vocabularyList[0] | null>(null);
  const leftPanelRef = useRef<HTMLDivElement>(null);
  const activeSectionRef = useRef<HTMLDivElement>(null);

  // Map Task index to section index to highlight relevant paragraphs
  // There are 6 tasks in While-Reading, let's map them to tale's sections
  let highlightedSectionId = tale.sections[0].id;
  if (taskIndex === 0) {
    highlightedSectionId = tale.sections[0].id; // section 1
  } else if (taskIndex === 1 || taskIndex === 3) {
    highlightedSectionId = tale.sections[1].id; // section 2
  } else if (taskIndex === 2 || taskIndex === 4) {
    highlightedSectionId = tale.sections[2].id; // section 3
  } else {
    highlightedSectionId = tale.sections[3].id; // section 4
  }

  // Scroll active section into view on the leftpanel
  useEffect(() => {
    if (activeSectionRef.current) {
      activeSectionRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
      });
    }
  }, [highlightedSectionId]);

  const currentAnswer = tempAnswers[task.id];
  const isChecked = checkedTasks[task.id] ?? false;

  // Render clickable text that highlights vocab terms
  const renderTextWithVocabHighlights = (text: string, highlights: { word: string; definition: string; kazakh?: string }[]) => {
    if (!highlights || highlights.length === 0) return <span>{text}</span>;

    // Build regex of highlights
    const wordsToMatch = highlights.map(h => h.word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
    if (!wordsToMatch) return <span>{text}</span>;

    const regex = new RegExp(`\\b(${wordsToMatch})\\b`, 'gi');
    const parts = text.split(regex);

    return parts.map((part, index) => {
      const isMatch = highlights.some(h => h.word.toLowerCase() === part.toLowerCase());
      if (isMatch) {
        // Find full vocab word data inside story vocabulary array to display detailed definition
        const matchedFullVocab = tale.vocabularyList.find(v => v.word.toLowerCase() === part.toLowerCase()) || {
          word: part,
          definition: highlights.find(h => h.word.toLowerCase() === part.toLowerCase())?.definition || '',
          example: 'Defined inside the paragraph.',
          kazakh: highlights.find(h => h.word.toLowerCase() === part.toLowerCase())?.kazakh || ''
        };

        return (
          <button
            key={index}
            onClick={() => setSelectedVocab(matchedFullVocab)}
            className="text-fairy-gold font-bold underline decoration-dotted decoration-fairy-gold hover:text-white hover:bg-fairy-gold/20 px-1 rounded cursor-pointer transition-all font-serif"
            title="Click to see vocabulary definition"
          >
            {part}
          </button>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  // Helper to reorder sequencing list (Move items up/down)
  const moveSequenceItem = (index: number, direction: 'up' | 'down') => {
    if (isChecked) return; // Locked when checked
    const list = Array.isArray(currentAnswer) 
      ? [...currentAnswer] 
      : [...(task as any).items];

    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= list.length) return;

    // Swap items
    const temp = list[index];
    list[index] = list[targetIndex];
    list[targetIndex] = temp;

    onAnswerChange(task.id, list);
  };

  // Make sure answer is initialized for sequencing, matching, dropdown blanks, etc.
  useEffect(() => {
    if (task.type === 'sequencing' && !currentAnswer) {
      // shuffle items initially for sequencing
      const shuffled = [...(task as any).items].sort(() => Math.random() - 0.5);
      onAnswerChange(task.id, shuffled);
    } else if (task.type === 'true-false' && !currentAnswer) {
      // create empty true-false answers object
      onAnswerChange(task.id, {});
    } else if (task.type === 'fill-in-blank' && !currentAnswer) {
      // initiate empty object
      onAnswerChange(task.id, {});
    }
  }, [task.id]);

  // Render question component in Right Panel
  const renderRightPanelContent = () => {
    switch (task.type) {
      case 'true-false': {
        const statements = (task as any).statements || [];
        const answersObj = currentAnswer || {};

        return (
          <div className="space-y-4" id={`tf-task-${task.id}`}>
            {statements.map((st: any) => {
              const selectedValue = answersObj[st.id]; // true | false | undefined
              const statementChecked = isChecked;
              const isCorrect = selectedValue === st.isTrue;

              let trueBtnStyle = 'border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-705';
              let falseBtnStyle = 'border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-705';

              if (selectedValue === true) {
                trueBtnStyle = statementChecked
                  ? isCorrect 
                    ? 'bg-emerald-500 border-emerald-500 text-fairy-navy' 
                    : 'bg-red-500 border-red-500 text-white'
                  : 'bg-[#4A9EAD] border-[#4A9EAD] text-fairy-navy';
              }
              if (selectedValue === false) {
                falseBtnStyle = statementChecked
                  ? isCorrect 
                    ? 'bg-emerald-500 border-emerald-500 text-fairy-navy' 
                    : 'bg-red-500 border-red-500 text-white'
                  : 'bg-[#4A9EAD] border-[#4A9EAD] text-fairy-navy';
              }

              return (
                <div key={st.id} className="bg-fairy-navy-lighter/30 border border-fairy-gold/10 rounded-xl p-4 space-y-3">
                  <p className="text-slate-200 text-sm leading-relaxed">{st.statement}</p>
                  
                  <div className="flex gap-2.5">
                    <button
                      disabled={statementChecked}
                      onClick={() => onAnswerChange(task.id, { ...answersObj, [st.id]: true })}
                      className={`flex-1 py-1 px-3 rounded text-xs font-mono font-bold tracking-wider uppercase border text-center transition-all cursor-pointer ${trueBtnStyle}`}
                    >
                      True
                    </button>
                    <button
                      disabled={statementChecked}
                      onClick={() => onAnswerChange(task.id, { ...answersObj, [st.id]: false })}
                      className={`flex-1 py-1 px-3 rounded text-xs font-mono font-bold tracking-wider uppercase border text-center transition-all cursor-pointer ${falseBtnStyle}`}
                    >
                      False
                    </button>
                  </div>

                  {statementChecked && (
                    <div className={`text-xs mt-2 p-2.5 rounded border leading-relaxed ${isCorrect ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>
                      <span className="font-bold flex items-center gap-1">
                        {isCorrect ? <Check className="w-3.5 h-3.5 shrink-0" /> : <X className="w-3.5 h-3.5 shrink-0" />}
                        {isCorrect ? 'Correct!' : 'Incorrect.'} {st.isTrue ? 'This is True.' : 'This is False.'}
                      </span>
                      <p className="mt-1 text-slate-300 text-[11px]">{st.explanation}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        );
      }

      case 'sequencing': {
        const itemsList = Array.isArray(currentAnswer) 
          ? currentAnswer 
          : (task as any).items || [];

        return (
          <div className="space-y-3" id={`seq-task-${task.id}`}>
            <p className="text-xs text-[#4A9EAD] font-mono uppercase tracking-wider mb-2">
              ★ Use Up/Down Arrows to place the steps in order:
            </p>

            {itemsList.map((item: any, idx: number) => {
              const isCorrectPosition = isChecked && item.correctOrder === idx;

              let borderStyle = 'border-fairy-gold/25 bg-fairy-navy-lighter/20';
              if (isChecked) {
                borderStyle = isCorrectPosition 
                  ? 'border-emerald-500/60 bg-emerald-950/25 text-emerald-400' 
                  : 'border-red-500/60 bg-red-950/25 text-red-400';
              }

              return (
                <div 
                  key={item.id} 
                  className={`flex items-center gap-3 p-3 rounded-xl border text-xs leading-relaxed transition-all ${borderStyle}`}
                >
                  {/* Position Badge indicator */}
                  <div className="w-6 h-6 rounded-full bg-slate-800/80 border border-fairy-gold/20 flex items-center justify-center font-mono font-bold text-slate-300">
                    {idx + 1}
                  </div>

                  <p className="flex-1 text-slate-200 text-[12px]">{item.text}</p>

                  {/* Ordering arrows */}
                  {!isChecked && (
                    <div className="flex flex-col gap-1">
                      <button
                        disabled={idx === 0}
                        onClick={() => moveSequenceItem(idx, 'up')}
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-300 cursor-pointer"
                        title="Move event up"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                      <button
                        disabled={idx === itemsList.length - 1}
                        onClick={() => moveSequenceItem(idx, 'down')}
                        className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-300 cursor-pointer"
                        title="Move event down"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                    </div>
                  )}

                  {isChecked && (
                    <div className="shrink-0">
                      {isCorrectPosition ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <div className="text-right">
                          <X className="w-4 h-4 text-red-400 inline" />
                          <span className="block text-[9px] text-[#4A9EAD] font-mono mt-0.5 font-bold">Should be #{item.correctOrder + 1}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        );
      }

      case 'detail-mc':
      case 'grammar-mc': {
        const options = (task as any).options || [];
        
        return (
          <div className="space-y-3" id={`mc-task-${task.id}`}>
            <p className="text-slate-200 text-sm font-medium leading-relaxed mb-4">{(task as any).question}</p>
            
            <div className="space-y-2.5">
              {options.map((opt: any) => {
                const isSelected = currentAnswer === opt.value;
                const modeChecked = isChecked;

                let stateStyle = 'border-slate-850 hover:border-fairy-gold-light bg-slate-900/40 text-slate-300';
                if (isSelected) {
                  stateStyle = 'border-fairy-gold bg-fairy-gold/10 text-fairy-gold font-medium';
                }

                if (modeChecked) {
                  if (opt.isCorrect) {
                    stateStyle = 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold';
                  } else if (isSelected && !opt.isCorrect) {
                    stateStyle = 'border-red-500 bg-red-400/10 text-red-400';
                  } else {
                    stateStyle = 'border-slate-850 bg-slate-900/20 text-slate-500 pointer-events-none';
                  }
                }

                return (
                  <button
                    key={opt.value}
                    disabled={modeChecked}
                    onClick={() => onAnswerChange(task.id, opt.value)}
                    className={`w-full text-left p-3.5 rounded-xl border text-xs md:text-sm leading-relaxed transition-all cursor-pointer ${stateStyle}`}
                  >
                    <div className="flex justify-between items-center gap-2">
                      <span>{opt.label}</span>
                      {modeChecked && opt.isCorrect && <Check className="w-4 h-4 text-emerald-400 shrink-0" />}
                      {modeChecked && isSelected && !opt.isCorrect && <X className="w-4 h-4 text-red-400 shrink-0" />}
                    </div>

                    {modeChecked && isSelected && (
                      <p className={`text-[10px] mt-2 border-t pt-2 font-mono ${opt.isCorrect ? 'text-emerald-400/80 border-emerald-500/25' : 'text-red-400/80 border-red-500/25'}`}>
                        {opt.feedback}
                      </p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        );
      }

      case 'vocab-context': {
        const correctVal = (task as any).correctWord;
        const candidateOptions = (task as any).options || [];

        return (
          <div className="space-y-4" id={`vocab-c-task-${task.id}`}>
            <p className="text-slate-300 text-xs font-mono tracking-wide uppercase bg-slate-900/60 p-3 rounded-lg border border-fairy-gold/10 leading-relaxed mb-4">
              "{(task as any).passage}"
            </p>

            <p className="text-slate-200 text-sm font-medium leading-relaxed mb-4">{(task as any).question}</p>

            <div className="flex flex-wrap gap-2.5">
              {candidateOptions.map((optWord: string) => {
                const isSelected = currentAnswer === optWord;
                const valCorrect = optWord === correctVal;

                let tabStyle = 'border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-750';
                if (isSelected) {
                  tabStyle = 'border-fairy-gold bg-fairy-gold text-fairy-navy font-bold';
                }

                if (isChecked) {
                  if (valCorrect) {
                    tabStyle = 'border-emerald-500 bg-emerald-500 text-fairy-navy font-bold';
                  } else if (isSelected && !valCorrect) {
                    tabStyle = 'border-red-500 bg-red-500 text-white';
                  } else {
                    tabStyle = 'border-slate-800 bg-slate-900/20 text-slate-600 pointer-events-none';
                  }
                }

                return (
                  <button
                    key={optWord}
                    disabled={isChecked}
                    onClick={() => onAnswerChange(task.id, optWord)}
                    className={`py-2 px-4 rounded-xl border font-serif text-sm transition-all cursor-pointer ${tabStyle}`}
                  >
                    {optWord}
                  </button>
                );
              })}
            </div>

            {isChecked && (
              <div className={`text-xs mt-3 p-3 rounded border leading-relaxed ${currentAnswer === correctVal ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>
                <span className="font-bold flex items-center gap-1 mb-1">
                  {currentAnswer === correctVal ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                  {currentAnswer === correctVal ? 'Correct!' : 'Try again!'}
                </span>
                <span>The correct target vocabulary word is <strong className="font-serif">"{correctVal}"</strong> which directly aligns with the defined meaning context.</span>
              </div>
            )}
          </div>
        );
      }

      case 'fill-in-blank': {
        const blanks = (task as any).blanks || [];
        const answersObj = currentAnswer || {};
        const textParts = (task as any).textWithBlanks.split(/\[blank\d+\]/g);

        return (
          <div className="space-y-4" id={`fill-task-${task.id}`}>
            <p className="text-slate-200 text-sm font-medium leading-relaxed">
              ★ Solve the paragraphs below by choosing the correct vocabulary choices:
            </p>

            {/* Render full text with dropdowns embedded */}
            <div className="bg-fairy-navy-lighter/35 border border-fairy-gold/10 p-5 rounded-2xl leading-loose text-sm text-slate-100">
              {blanks.map((bk: any, idx: number) => {
                return (
                  <span key={bk.key} className="inline flex-wrap">
                    {textParts[idx]}
                    <select
                      disabled={isChecked}
                      value={answersObj[bk.key] || ''}
                      onChange={(e) => onAnswerChange(task.id, { ...answersObj, [bk.key]: e.target.value })}
                      className={`inline-block mx-1.5 px-2 py-1 text-xs font-mono font-semibold rounded border bg-fairy-navy text-fairy-gold cursor-pointer ${isChecked ? (answersObj[bk.key] === bk.correctAnswer ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400' : 'border-red-500 bg-red-400/10 text-red-400') : 'border-fairy-gold/40'}`}
                    >
                      <option value="">-- Choose Word --</option>
                      {bk.options.map((opt: string) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </span>
                );
              })}
              {textParts[blanks.length]}
            </div>

            {/* Post checking summaries */}
            {isChecked && (
              <div className="space-y-2.5 mt-4">
                {blanks.map((bk: any) => {
                  const correct = answersObj[bk.key] === bk.correctAnswer;
                  return (
                    <div key={bk.key} className={`text-xs p-2.5 rounded border leading-relaxed flex gap-2 ${correct ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-00'}`}>
                      {correct ? <Check className="w-4 h-4 shrink-0 mt-0.5" /> : <X className="w-4 h-4 shrink-0 mt-0.5" />}
                      <div>
                        <strong className="font-mono uppercase text-[9px] block">Dropdown blank {bk.key.replace('blank', '#')}:</strong>
                        <span>Correct Answer is <strong className="font-bold font-serif text-white">"{bk.correctAnswer}"</strong>. (You picked: "{answersObj[bk.key] || 'Empty'}")</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      }

      default:
        return <p>Fallback: Task of type {task.type} is loading.</p>;
    }
  };

  return (
    <div className="max-w-7xl w-full grid grid-cols-1 lg:grid-cols-12 gap-6 px-4 md:px-8 py-6 z-20 flex-1 relative select-none" id="split-reader">
      
      {/* LEFT PANEL: 60% Width Stories scroll */}
      <div 
        ref={leftPanelRef}
        className="col-span-1 lg:col-span-7 bg-fairy-navy-lighter/25 border border-fairy-gold/15 rounded-3xl p-5 md:p-8 flex flex-col gap-6 overflow-y-auto max-h-[75vh]"
        id="left-story-scroller"
      >
        <div className="flex justify-between items-center border-b border-fairy-gold/10 pb-4 shrink-0">
          <span className="text-xs font-mono text-[#4A9EAD] uppercase tracking-wider flex items-center gap-1.5 font-bold">
            <BookMarked className="w-4 h-4 text-fairy-teal" /> Read & Tap Highlights
          </span>
          <span className="text-[10px] text-slate-400">Section focus shifts with tasks</span>
        </div>

        {/* List of tale paragraphs */}
        <div className="space-y-6">
          {tale.sections.map((sec, secIdx) => {
            const isSectionFocused = sec.id === highlightedSectionId;
            return (
              <div
                key={sec.id}
                ref={isSectionFocused ? activeSectionRef : null}
                className={`p-5 rounded-2xl border transition-all duration-300 ${isSectionFocused ? 'border-fairy-gold bg-fairy-navy-light/60 scale-[1.01] shadow-lg shadow-fairy-gold/5' : 'border-transparent opacity-45'}`}
                id={`story-section-${sec.id}`}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className={`w-2.5 h-2.5 rounded-full ${isSectionFocused ? 'bg-fairy-gold animate-ping' : 'bg-slate-700'}`} />
                  <h4 className={`text-sm font-bold font-mono tracking-wider uppercase ${isSectionFocused ? 'text-fairy-gold' : 'text-slate-400'}`}>
                    {sec.title}
                  </h4>
                </div>

                <p className="font-serif text-base md:text-lg leading-relaxed text-slate-100 italic md:not-italic tracking-wide text-justify">
                  {renderTextWithVocabHighlights(sec.content, sec.vocabularyHighlights)}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* RIGHT PANEL: 40% Width Question Sheets */}
      <div 
        className="col-span-1 lg:col-span-5 bg-fairy-navy-light/50 border border-fairy-gold/20 rounded-3xl p-5 md:p-6 flex flex-col justify-between overflow-y-auto max-h-[75vh] shadow-xl"
        id="right-task-container"
      >
        <div className="space-y-5">
          {/* Diagnostic Category header tag */}
          <div className="flex justify-between items-center bg-slate-900/60 p-3 rounded-xl border border-slate-800">
            <div>
              <span className="block text-[9px] uppercase tracking-widest text-[#4A9EAD] font-mono leading-tight">
                Pedagogical Skill Dimension
              </span>
              <span className="text-xs text-fairy-gold font-mono font-bold tracking-wide">
                ✦ {task.skill === 'MAIN_IDEA' ? 'Main Idea ID' : task.skill.replace('_', ' ')}
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono font-bold">
              Task {taskIndex + 1} of {totalTaskCount}
            </span>
          </div>

          {/* Prompt card title */}
          <div>
            <h3 className="font-serif text-lg md:text-xl font-bold text-fairy-cream">
              {task.title}
            </h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              {task.instruction}
            </p>
          </div>

          {/* Dynamic tasks renderers */}
          <div className="border-t border-fairy-gold/10 pt-4" id="task-fields">
            {renderRightPanelContent()}
          </div>
        </div>

        {/* Footer actions of right panel */}
        <div className="border-t border-fairy-gold/10 pt-4 mt-8 space-y-3 shrink-0">
          
          {/* Submit Action Block */}
          {!isChecked ? (
            <button
              onClick={() => onCheckAnswer(task.id)}
              className="w-full flex items-center justify-center gap-2 bg-[#4A9EAD] hover:bg-white text-fairy-navy font-bold py-3 px-4 rounded-xl cursor-pointer transition-all active:scale-[0.98] shadow-md hover:shadow-teal-400/10 text-sm font-sans"
              id="btn-check-answer"
            >
              Check Answer
            </button>
          ) : (
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs text-center py-2.5 px-4 rounded-xl font-mono flex items-center justify-center gap-1.5">
              <Check className="w-4 h-4" /> Response Registered & Verified!
            </div>
          )}

          {/* Stepper controls */}
          <div className="flex gap-2.5">
            <button
              disabled={taskIndex === 0}
              onClick={onPrevTask}
              className="flex-1 flex items-center justify-center gap-2.5 py-2.5 px-3 border border-fairy-gold/10 hover:border-fairy-gold bg-transparent hover:bg-fairy-gold/5 text-xs text-fairy-gold rounded-xl cursor-pointer transition-all disabled:opacity-30 disabled:hover:bg-transparent"
              id="btn-prev-task"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Previous Task
            </button>
            
            {taskIndex < totalTaskCount - 1 ? (
              <button
                disabled={!isChecked}
                onClick={onNextTask}
                className="flex-1 flex items-center justify-center gap-2.5 py-2.5 px-3 bg-fairy-gold hover:bg-white text-xs font-bold text-fairy-navy rounded-xl cursor-pointer transition-all disabled:opacity-40 disabled:hover:bg-fairy-gold disabled:hover:text-fairy-navy"
                id="btn-next-task"
              >
                Next Task <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                disabled={!isChecked}
                onClick={onCompletePhase}
                className="flex-1 flex items-center justify-center gap-2.5 py-2.5 px-3 bg-emerald-500 hover:bg-white text-xs font-bold text-fairy-navy rounded-xl cursor-pointer transition-all disabled:opacity-45 disabled:hover:bg-emerald-500 disabled:hover:text-fairy-navy"
                id="btn-complete-while"
              >
                Review Highlights!
              </button>
            )}
          </div>
        </div>

      </div>

      {/* Vocabulary detailed definition popup modal */}
      <AnimatePresence>
        {selectedVocab && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedVocab(null)}
          >
            <motion.div 
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-fairy-navy-light border-2 border-fairy-gold rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl space-y-5"
              onClick={(e) => e.stopPropagation()}
              id="vocab-modal"
            >
              <div className="flex justify-between items-start border-b border-fairy-gold/10 pb-3">
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-[#4A9EAD] uppercase bg-[#4A9EAD]/10 px-2.5 py-0.5 rounded-full font-bold">
                    Key Vocabulary Definition
                  </span>
                  <h3 className="font-serif text-3xl font-bold text-fairy-cream mt-2 tracking-wide">
                    {selectedVocab.word}
                  </h3>
                </div>
                <button 
                  onClick={() => setSelectedVocab(null)}
                  className="p-1 px-2.5 text-xs text-slate-400 hover:text-white border border-slate-750 hover:border-white rounded-lg cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {selectedVocab.kazakh && (
                <div className="bg-fairy-gold/10 border border-fairy-gold/20 p-3 rounded-xl">
                  <span className="block text-[10px] uppercase font-mono text-fairy-gold">Kazakh Translation:</span>
                  <p className="text-fairy-gold-light text-base font-medium mt-0.5 font-serif">
                    {selectedVocab.kazakh}
                  </p>
                </div>
              )}

              <div className="space-y-1.5">
                <span className="block text-[10.5px] uppercase font-mono text-slate-500">Meaning of the Word:</span>
                <p className="text-slate-200 text-sm leading-relaxed text-justify">
                  {selectedVocab.definition}
                </p>
              </div>

              <div className="space-y-1.5 bg-slate-900/40 border border-slate-800 p-3 rounded-xl italic">
                <span className="block text-[10.5px] uppercase font-mono text-slate-500 not-italic">Example in Context:</span>
                <p className="text-slate-300 text-xs leading-relaxed font-serif">
                  "{selectedVocab.example}"
                </p>
              </div>

              <button
                onClick={() => setSelectedVocab(null)}
                className="w-full py-2.5 bg-fairy-gold hover:bg-white text-fairy-navy font-bold rounded-xl transition-all cursor-pointer text-xs uppercase tracking-wider"
              >
                Close Dictionary
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
