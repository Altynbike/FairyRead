import { Tale, StudentRegistry } from '../types';
import { BookOpen, Award, CheckCircle, RefreshCw, Star, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface MainLandingProps {
  tales: Tale[];
  registry: StudentRegistry;
  onSelectTale: (taleId: string) => void;
  onResetProgress: () => void;
}

export default function MainLanding({ tales, registry, onSelectTale, onResetProgress }: MainLandingProps) {
  // Sparkle background decoration elements positions
  const sparkles = [
    { top: '15%', left: '8%', size: 4, delay: 0 },
    { top: '25%', left: '85%', size: 6, delay: 1.5 },
    { top: '70%', left: '5%', size: 5, delay: 2.5 },
    { top: '80%', left: '92%', size: 4, delay: 0.8 },
    { top: '50%', left: '75%', size: 7, delay: 3 },
    { top: '10%', left: '50%', size: 5, delay: 2.1 }
  ];

  return (
    <div className="relative min-h-screen bg-fairy-navy flex flex-col items-center py-10 px-4 md:px-8 overflow-hidden select-none" id="landing-page">
      {/* Sparkles Overlay */}
      {sparkles.map((sp, idx) => (
        <div
          key={idx}
          className="absolute rounded-full bg-fairy-gold animate-sparkle"
          style={{
            top: sp.top,
            left: sp.left,
            width: `${sp.size}px`,
            height: `${sp.size}px`,
            animationDelay: `${sp.delay}s`,
            boxShadow: '0 0 10px #D4AF37'
          }}
        />
      ))}

      {/* Hero Header */}
      <div className="max-w-4xl text-center z-10 mt-10 md:mt-16 flex flex-col items-center">
        {/* Animated Badge */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 bg-fairy-gold/15 border border-fairy-gold/30 rounded-full px-4 py-1.5 text-fairy-gold text-xs font-mono mb-6 uppercase tracking-widest"
          id="hero-badge"
        >
          <Award className="w-4 h-4" /> Grade 7 EFL Reading Skills Platform • Kazakhstan
        </motion.div>

        {/* Master Title */}
        <motion.h1 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="font-serif text-5xl md:text-7xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-fairy-cream via-fairy-gold to-fairy-cream drop-shadow-lg mb-4"
          id="main-title"
        >
          FairyRead
        </motion.h1>

        {/* Tagline */}
        <p className="font-serif italic text-fairy-gold/90 text-xl font-medium tracking-wide mb-6">
          "Learn to Read. Learn to Think."
        </p>

        {/* Platform Description */}
        <div className="max-w-2xl bg-fairy-navy-card/40 backdrop-blur-md border border-fairy-gold/10 rounded-2xl p-6 shadow-2xl mb-12">
          <p className="text-slate-300 leading-relaxed text-sm md:text-base">
            Welcome to <strong className="text-fairy-cream">FairyRead</strong>, an interactive digital platform designed to develop English reading comprehension skills through classic folk fables. Complete the guided <strong className="text-fairy-gold">Pre-reading ➜ While-reading ➜ Post-reading</strong> stages to test your vocabulary, find key details, sequence story events, and unlock analytical diagnostic reports!
          </p>
        </div>

        {/* CTA Banner */}
        <h3 className="font-serif text-2xl text-fairy-cream font-semibold mb-8 flex items-center gap-3">
          <BookOpen className="w-5 h-5 text-fairy-teal" /> Choose a Folk Tale to Begin
        </h3>
      </div>

      {/* Tales Bento Grid */}
      <div className="max-w-6xl w-full grid grid-cols-1 md:grid-cols-3 gap-8 px-2 md:px-6 z-10 mb-16" id="tales-grid">
        {tales.map((tale, index) => {
          const state = registry[tale.id];
          const isCompleted = state?.completedPhases?.pre && state?.completedPhases?.while && state?.completedPhases?.post;
          const isStarted = state && (state.completedPhases.pre || state.completedPhases.while);
          const score = state?.score;
          
          let statusBadge = (
            <span className="bg-slate-800 text-slate-400 text-[10px] uppercase font-mono tracking-widest px-2.5 py-1 rounded-full border border-slate-700">
              Not Started
            </span>
          );
          if (isCompleted) {
            statusBadge = (
              <span className="bg-emerald-500/15 text-emerald-400 text-[10px] uppercase font-mono tracking-widest px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5" /> Score: {score}/100
              </span>
            );
          } else if (isStarted) {
            statusBadge = (
              <span className="bg-fairy-teal/15 text-fairy-teal-light text-[10px] uppercase font-mono tracking-widest px-2.5 py-1 rounded-full border border-fairy-teal/30">
                In Progress
              </span>
            );
          }

          let diffColor = 'text-green-400 bg-green-500/10 border-green-500/20';
          if (tale.difficulty === 'Medium') diffColor = 'text-fairy-gold bg-fairy-gold/10 border-fairy-gold/20';
          if (tale.difficulty === 'Hard') diffColor = 'text-red-400 bg-red-500/10 border-red-500/20';

          return (
            <motion.div
              key={tale.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.15 }}
              whileHover={{ y: -8, scale: 1.01 }}
              className="group relative bg-fairy-navy-light/70 backdrop-blur-sm border border-fairy-gold/20 rounded-3xl p-6 flex flex-col justify-between shadow-xl shadow-black/30 hover:shadow-fairy-gold/10 hover:border-fairy-gold/50 transition-all duration-300"
              id={`tale-card-${tale.id}`}
            >
              <div>
                {/* Header Row */}
                <div className="flex justify-between items-start mb-6">
                  <div className="w-12 h-12 bg-fairy-navy-lighter/80 border border-fairy-gold/30 rounded-2xl flex items-center justify-center text-2xl group-hover:bg-fairy-gold/20 group-hover:border-fairy-gold transition-all duration-300 shadow-md">
                    {tale.icon}
                  </div>
                  <div className="flex flex-col items-end gap-1.5">
                    {statusBadge}
                    <span className={`text-[10px] uppercase font-mono tracking-wider px-2 py-0.5 rounded-md border ${diffColor}`}>
                      {tale.difficulty}
                    </span>
                  </div>
                </div>

                {/* Theme & Title */}
                <span className="text-[11px] font-mono tracking-widest text-[#4A9EAD] uppercase font-medium">
                  Theme: {tale.theme}
                </span>
                
                <h4 className="font-serif text-2xl font-bold text-fairy-cream mt-1 mb-3 leading-tight group-hover:text-fairy-gold transition-colors duration-200">
                  {tale.title}
                </h4>

                {/* Teaser Description */}
                <p className="text-slate-300 text-sm leading-relaxed mb-6">
                  {tale.teaser}
                </p>

                {/* Metadata Items */}
                <div className="grid grid-cols-2 gap-3 text-xs text-slate-400 border-t border-fairy-gold/10 pt-4 mb-4 font-mono">
                  <div>
                    <span className="block text-[10px] text-slate-500 uppercase tracking-wider">Estimated Time</span>
                    <span className="text-slate-300">~{tale.durationMinutes} min</span>
                  </div>
                  <div>
                    <span className="block text-[10px] text-slate-500 uppercase tracking-wider">Grammar Target</span>
                    <span className="text-fairy-gold/90 truncate block max-w-[130px]">{tale.grammarFocus.split(' ')[0]}</span>
                  </div>
                </div>
              </div>

              {/* CTA Action button */}
              <button
                onClick={() => onSelectTale(tale.id)}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-medium text-sm transition-all duration-300 cursor-pointer text-fairy-navy bg-fairy-gold hover:bg-white border border-fairy-gold/50 hover:border-white shadow-md active:scale-[0.98]"
              >
                {isCompleted ? 'Review Diagnostics' : isStarted ? 'Continue Reading' : 'Start Reading'}
                <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </div>

      {/* Bottom Toolbars & Reset options */}
      <div className="max-w-4xl w-full z-10 border-t border-fairy-gold/10 pt-10 flex flex-col md:flex-row justify-between items-center gap-6 px-4">
        <div className="text-center md:text-left">
          <p className="text-xs text-slate-400 font-mono">
            Designed for <strong className="text-fairy-gold">Kazakhstan Grade 7 EFL Students</strong>
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            Aligned with the national curriculum frameworks on Reading Skills formation.
          </p>
        </div>

        {/* Reset Progress Button */}
        <button
          onClick={() => {
            if (window.confirm("Are you sure you want to reset all your progress data? This will clear all finished tales and diagnostic scores.")) {
              onResetProgress();
            }
          }}
          className="flex items-center gap-2 text-xs text-slate-400 hover:text-red-400 cursor-pointer bg-fairy-navy-lighter/40 border border-fairy-gold/10 hover:border-red-400/30 px-3 py-2 rounded-xl transition-all duration-200"
          id="btn-reset-progress"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Reset Platform State
        </button>
      </div>

      {/* Floating Sparkle Elements underneath */}
      <div className="absolute top-1/2 left-1/4 w-[400px] h-[400px] rounded-full bg-fairy-gold/5 blur-[120px] pointer-events-none select-none z-0" />
      <div className="absolute bottom-10 right-1/4 w-[350px] h-[350px] rounded-full bg-fairy-teal/5 blur-[100px] pointer-events-none select-none z-0" />
    </div>
  );
}
