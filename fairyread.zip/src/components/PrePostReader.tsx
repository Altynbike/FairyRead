import { useState, useEffect } from 'react';
import { Task, StudentAnswers } from '../types';
import { 
  Check, 
  X, 
  ArrowLeft, 
  ArrowRight, 
  Sparkles, 
  Info, 
  HelpCircle, 
  CheckCircle,
  Hash,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import { motion } from 'motion/react';

interface PrePostReaderProps {
  task: Task;
  taskIndex: number;
  totalTaskCount: number;
  tempAnswers: StudentAnswers;
  onAnswerChange: (taskId: string, answer: any) => void;
  onPrevTask: () => void;
  onNextTask: () => void;
  onCheckAnswer: (taskId: string) => void;
  checkedTasks: { [taskId: string]: boolean };
  onCompletePhase: () => void;
}

export default function PrePostReader({
  task,
  taskIndex,
  totalTaskCount,
  tempAnswers,
  onAnswerChange,
  onPrevTask,
  onNextTask,
  onCheckAnswer,
  checkedTasks,
  onCompletePhase,
}: PrePostReaderProps) {
  const currentAnswer = tempAnswers[task.id];
  const isChecked = checkedTasks[task.id] ?? false;

  // Matching game temporary state
  const [selectedWordId, setSelectedWordId] = useState<string | null>(null);
  const [selectedDefId, setSelectedDefId] = useState<string | null>(null);

  // Initialize matching, MindMap, or slider answer if empty
  useEffect(() => {
    if (task.type === 'matching' && !currentAnswer) {
      // Structure: { pairsMatched: { [wordId]: defId }, completedPairs: string[] }
      onAnswerChange(task.id, { pairsMatched: {}, completedPairs: [] });
    } else if (task.type === 'mind-map' && !currentAnswer) {
      // Structure: array of names of highlighted traits
      onAnswerChange(task.id, []);
    } else if ((task as any).type === 'retelling' && !currentAnswer) {
      // shuffle summarizing sentences initially
      const shuffled = [...(task as any).items].sort(() => Math.random() - 0.5);
      onAnswerChange(task.id, shuffled);
    } else if (task.type === 'prediction-slider' && !currentAnswer) {
      // Select the first option as default
      onAnswerChange(task.id, (task as any).options[0].value);
    }
  }, [task.id]);

  // Handler for matching pairs
  const handleMatchSelect = (type: 'word' | 'def', id: string) => {
    if (isChecked) return;
    const matchData = currentAnswer || { pairsMatched: {}, completedPairs: [] };
    const pairsMatched = { ...matchData.pairsMatched };

    if (type === 'word') {
      setSelectedWordId(id);
      if (selectedDefId) {
        // Form a pair
        pairsMatched[id] = selectedDefId;
        onAnswerChange(task.id, {
          pairsMatched,
          completedPairs: [...matchData.completedPairs, id]
        });
        setSelectedWordId(null);
        setSelectedDefId(null);
      }
    } else {
      setSelectedDefId(id);
      if (selectedWordId) {
        // Form a pair
        pairsMatched[selectedWordId] = id;
        onAnswerChange(task.id, {
          pairsMatched,
          completedPairs: [...matchData.completedPairs, selectedWordId]
        });
        setSelectedWordId(null);
        setSelectedDefId(null);
      }
    }
  };

  // Undo a specific pair match
  const handleUndoMatch = (wordId: string) => {
    if (isChecked) return;
    const matchData = currentAnswer || { pairsMatched: {}, completedPairs: [] };
    const pairsMatched = { ...matchData.pairsMatched };
    delete pairsMatched[wordId];
    
    onAnswerChange(task.id, {
      pairsMatched,
      completedPairs: matchData.completedPairs.filter((w: string) => w !== wordId)
    });
  };

  // Trait clicker for Mind map (exactly 3 required)
  const handleTraitToggle = (traitName: string) => {
    if (isChecked) return;
    const traits = currentAnswer || [];
    if (traits.includes(traitName)) {
      onAnswerChange(task.id, traits.filter((t: string) => t !== traitName));
    } else {
      if (traits.length < (task as any).requiredCount) {
        onAnswerChange(task.id, [...traits, traitName]);
      } else {
        // replace first item if exceeded
        onAnswerChange(task.id, [...traits.slice(1), traitName]);
      }
    }
  };

  // Up/down chronological mover for retelling sentences
  const moveRetellingItem = (index: number, direction: 'up' | 'down') => {
    if (isChecked) return;
    const list = Array.isArray(currentAnswer) 
      ? [...currentAnswer] 
      : [...(task as any).items];

    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= list.length) return;

    // Swap items
    const temp = list[index];
    list[index] = list[targetIndex];
    list[targetIndex] = temp;

    onAnswerChange(task.id, list);
  };

  // Calculate word counter for creative letters
  const getWordCount = (val: string) => {
    if (!val) return 0;
    return val.trim().split(/\s+/).filter(Boolean).length;
  };

  const renderContent = () => {
    const taskType = (task as any).type;
    switch (taskType) {
      
      case 'prediction':
      case 'text-warmup': {
        const val = currentAnswer || '';
        const pl = (task as any).placeholder || 'Write here in English...';
        return (
          <div className="space-y-4" id={`text-task-${task.id}`}>
            {task.type === 'text-warmup' && (
              <p className="text-fairy-gold font-serif italic text-base md:text-lg mb-3 leading-relaxed">
                "{ (task as any).question }"
              </p>
            )}
            
            <textarea
              disabled={isChecked}
              value={val}
              onChange={(e) => onAnswerChange(task.id, e.target.value)}
              placeholder={pl}
              className="w-full h-36 bg-slate-900 border border-fairy-gold/25 rounded-2xl p-4 text-xs md:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-fairy-gold leading-relaxed font-sans"
            />
            
            <div className="flex justify-between items-center text-xs font-mono text-slate-500">
              <span>Characters: {val.length}</span>
              <span>Words: {getWordCount(val)}</span>
            </div>

            {isChecked && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs p-3.5 rounded-xl leading-relaxed">
                <span className="font-bold block font-mono">🏆 Effort Credit Added (+100%):</span>
                <span>Writing down predictions and reflections in English activates vocabulary skills beautifully! Outstanding work expressing yourself.</span>
              </div>
            )}
          </div>
        );
      }

      case 'matching': {
        const pairs = (task as any).pairs || [];
        const matchData = currentAnswer || { pairsMatched: {}, completedPairs: [] };
        
        // words list derived correctly
        const words = pairs.map((p: any) => ({ id: p.id, word: p.word }));
        // definitions list shuffled or statically generated with specific keys
        const definitions = pairs.map((p: any) => ({ id: p.id, definition: p.definition }));

        return (
          <div className="space-y-6" id={`matching-task-${task.id}`}>
            <p className="text-xs text-[#4A9EAD] font-mono tracking-widest uppercase mb-4">
              ★ Click a vocabulary word, then click its matching definitions:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Words Panel */}
              <div className="space-y-2.5">
                <h5 className="text-[10px] font-mono uppercase tracking-widest text-slate-500 mb-2">English Vocabulary Word</h5>
                {words.map((w: any) => {
                  const isAlreadyMatched = matchData.completedPairs.includes(w.id);
                  const isWordSelected = selectedWordId === w.id;

                  let borderStyle = 'border-slate-800 bg-slate-900/60 text-slate-300';
                  if (isWordSelected) borderStyle = 'border-fairy-gold bg-fairy-gold/10 text-fairy-gold scale-[1.02] shadow-md shadow-fairy-gold/5';
                  if (isAlreadyMatched) borderStyle = 'border-emerald-500/40 bg-emerald-950/15 text-slate-400 opacity-60';

                  return (
                    <button
                      key={w.id}
                      disabled={isChecked || isAlreadyMatched}
                      onClick={() => handleMatchSelect('word', w.id)}
                      className={`w-full text-left p-3 rounded-xl border text-xs md:text-sm font-bold font-serif transition-all cursor-pointer ${borderStyle}`}
                    >
                      <div className="flex justify-between items-center">
                        <span>{w.word}</span>
                        {isAlreadyMatched && <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded uppercase font-mono tracking-widest font-bold">Linked</span>}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Definitions Panel */}
              <div className="space-y-2.5">
                <h5 className="text-[10px] font-mono uppercase tracking-widest text-slate-500 mb-2">English Definitions (Meaning)</h5>
                {definitions.map((d: any) => {
                  const isIncludedInMatch = Object.values(matchData.pairsMatched).includes(d.id);
                  const isWordThatMatchedMe = Object.keys(matchData.pairsMatched).find(k => matchData.pairsMatched[k] === d.id);
                  const isDefSelected = selectedDefId === d.id;

                  let borderStyle = 'border-slate-800 bg-slate-900/60 text-slate-300';
                  if (isDefSelected) borderStyle = 'border-fairy-gold bg-fairy-gold/10 text-fairy-gold';
                  if (isIncludedInMatch) borderStyle = 'border-emerald-500/40 bg-emerald-950/15 text-slate-400 opacity-60';

                  return (
                    <button
                      key={d.id}
                      disabled={isChecked || isIncludedInMatch}
                      onClick={() => handleMatchSelect('def', d.id)}
                      className={`w-full text-left p-3 rounded-xl border text-xs leading-relaxed transition-all cursor-pointer ${borderStyle}`}
                    >
                      <div className="flex items-start gap-2">
                        <span className="flex-1 text-[11.5px]">{d.definition}</span>
                        {isIncludedInMatch && isWordThatMatchedMe && (
                          <button
                            disabled={isChecked}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleUndoMatch(isWordThatMatchedMe);
                            }}
                            className="bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white px-1.5 py-0.5 rounded text-[9px] font-bold uppercase transition-colors"
                            title="Undo match connection"
                          >
                            Undo
                          </button>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Verification checking lists */}
            {isChecked && (
              <div className="space-y-2 pt-4 border-t border-fairy-gold/10">
                <p className="text-xs font-mono uppercase tracking-wide text-slate-400 mb-2">Evaluation Breakdown:</p>
                {pairs.map((p: any) => {
                  const selectionDefId = matchData.pairsMatched[p.id];
                  const correct = selectionDefId === p.id;
                  
                  return (
                    <div 
                      key={p.id} 
                      className={`text-xs p-3 rounded-xl border leading-relaxed flex gap-2.5 ${correct ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}
                    >
                      {correct ? <Check className="w-4 h-4 mt-0.5 shrink-0" /> : <X className="w-4 h-4 mt-0.5 shrink-0" />}
                      <div>
                        <span className="font-bold block font-serif text-white">"{p.word}"</span>
                        <span className="text-slate-300 block text-[11px] mt-0.5">Correct Match Definition: {p.definition}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      }

      case 'prediction-slider': {
        const options = (task as any).options || [];
        const activeOption = options.find((o: any) => o.value === currentAnswer) || options[0];

        return (
          <div className="space-y-6" id={`slider-task-${task.id}`}>
            <p className="text-xs text-[#4A9EAD] font-mono tracking-widest uppercase mb-4">
              ★ Review the 3 plot options and select the most likely outcome:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {options.map((opt: any) => {
                const isSelected = currentAnswer === opt.value;
                return (
                  <button
                    key={opt.value}
                    disabled={isChecked}
                    onClick={() => onAnswerChange(task.id, opt.value)}
                    className={`text-left p-4 rounded-xl border transition-all cursor-pointer ${isSelected ? 'border-fairy-gold bg-fairy-gold/10 text-fairy-gold font-bold scale-[1.01] shadow-md shadow-fairy-gold/5' : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700'}`}
                  >
                    <span className="block text-xs font-mono uppercase tracking-wider text-slate-500 mb-1">Plot Path</span>
                    <span className="block font-serif text-sm md:text-base leading-tight font-bold mb-2">{opt.label}</span>
                    <span className="block text-[11px] text-slate-400 leading-normal font-normal">{opt.description}</span>
                  </button>
                );
              })}
            </div>

            {isChecked && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs p-3.5 rounded-xl leading-relaxed">
                <span className="font-bold block font-mono">🏆 Prediction Recorded:</span>
                <span>"<strong>{activeOption.label}</strong>" is locked as your pre-reading prediction. Let's read the tale to see if the fables align with your path!</span>
              </div>
            )}
          </div>
        );
      }

      case 'inference-mc':
      case 'moral-mc': {
        const options = (task as any).options || [];
        
        return (
          <div className="space-y-4" id={`mc-task-${task.id}`}>
            <p className="text-fairy-cream font-medium text-sm md:text-base leading-relaxed mb-6">
              {(task as any).question}
            </p>

            <div className="space-y-3">
              {options.map((opt: any) => {
                const isSelected = currentAnswer === opt.value;
                const modeChecked = isChecked;

                let stateStyle = 'border-slate-800 bg-slate-900/40 text-slate-300 hover:border-fairy-gold/40';
                if (isSelected) {
                  stateStyle = 'border-fairy-gold bg-fairy-gold/10 text-fairy-gold font-medium';
                }

                if (modeChecked) {
                  if (opt.isCorrect) {
                     stateStyle = 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold';
                  } else if (isSelected && !opt.isCorrect) {
                     stateStyle = 'border-red-500 bg-red-400/10 text-red-400';
                  } else {
                     stateStyle = 'border-slate-900 bg-slate-950/20 text-slate-500 pointer-events-none';
                  }
                }

                return (
                  <button
                    key={opt.value}
                    disabled={modeChecked}
                    onClick={() => onAnswerChange(task.id, opt.value)}
                    className={`w-full text-left p-4 rounded-xl border text-xs md:text-sm leading-relaxed transition-all cursor-pointer ${stateStyle}`}
                  >
                    <div className="flex justify-between items-center gap-2">
                      <span>{opt.label}</span>
                      {modeChecked && opt.isCorrect && <Check className="w-4 h-4 text-emerald-400 shrink-0" />}
                      {modeChecked && isSelected && !opt.isCorrect && <X className="w-4 h-4 text-red-400 shrink-0" />}
                    </div>

                    {modeChecked && isSelected && (
                      <p className={`text-[10px] mt-2 border-t pt-2 font-mono ${opt.isCorrect ? 'text-emerald-400/80 border-emerald-500/25' : 'text-red-400/80 border-red-500/25'}`}>
                        {opt.feedback}
                      </p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        );
      }

      case 'mind-map': {
        const charName = (task as any).characterName;
        const traits = (task as any).traits || [];
        const checkedTraits = currentAnswer || [];
        const requiredCount = (task as any).requiredCount;

        return (
          <div className="space-y-6" id={`mindmap-${task.id}`}>
            <p className="text-xs text-[#4A9EAD] font-mono tracking-widest uppercase mb-4">
              ★ Select exactly <strong className="text-white">{requiredCount}</strong> character traits that describe <strong className="text-white font-serif">{charName}</strong>:
            </p>

            <div className="flex flex-col items-center">
              
              {/* Circular Graphical display */}
              <div className="relative w-full max-w-lg min-h-[290px] flex items-center justify-center p-4">
                
                {/* Center Bubble */}
                <div className="w-24 h-24 rounded-full bg-fairy-navy-light border-2 border-fairy-gold animate-gold-glow flex flex-col items-center justify-center z-10 text-center shadow-lg">
                  <span className="text-[10px] uppercase tracking-wider font-mono text-fairy-gold">Character</span>
                  <span className="font-serif text-lg font-bold text-fairy-cream mt-0.5">{charName}</span>
                </div>

                {/* Satellite Trait Nodes */}
                <div className="absolute inset-0 grid grid-cols-2 md:grid-cols-3 gap-4 items-center justify-center content-center select-none pointer-events-none">
                  {traits.map((tr: any, idx: number) => {
                    const isSelected = checkedTraits.includes(tr.trait);
                    const pointerEvents = isChecked ? 'none' : 'auto';

                    let nodeStyle = 'border-slate-800 bg-slate-900/90 text-slate-350';
                    if (isSelected) {
                      nodeStyle = 'border-fairy-gold bg-fairy-gold text-fairy-navy font-bold shadow-md shadow-fairy-gold/10';
                    }

                    if (isChecked) {
                      if (tr.isCorrect) {
                        nodeStyle = 'border-emerald-500 bg-emerald-500/10 text-emerald-400 font-bold';
                      } else if (isSelected && !tr.isCorrect) {
                        nodeStyle = 'border-red-500 bg-red-450/10 text-red-400';
                      } else {
                        nodeStyle = 'border-slate-900 bg-slate-950/20 text-slate-500 opacity-40';
                      }
                    }

                    return (
                      <button
                        key={idx}
                        disabled={isChecked}
                        onClick={() => handleTraitToggle(tr.trait)}
                        className={`p-3.5 rounded-2xl border text-xs text-center transition-all shadow-md pointer-events-auto cursor-pointer ${nodeStyle}`}
                        style={{ pointerEvents }}
                      >
                        {tr.trait}
                      </button>
                    );
                  })}
                </div>

              </div>

              {/* Status Indicator */}
              <p className="text-xs font-mono text-slate-400 mt-4">
                Selected: <strong className="text-fairy-gold">{checkedTraits.length}</strong> / {requiredCount}
              </p>
            </div>

            {/* Mindmap feedback summaries */}
            {isChecked && (
              <div className="space-y-2 pt-4 border-t border-fairy-gold/10">
                <p className="text-xs font-mono uppercase tracking-wide text-slate-400 mb-2">Traits Diagnostics Analysis:</p>
                {traits.map((tr: any, idx: number) => {
                  const wasSelected = checkedTraits.includes(tr.trait);
                  return (
                    <div 
                      key={idx} 
                      className={`text-xs p-3 rounded-xl border leading-relaxed flex gap-2.5 ${tr.isCorrect ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : wasSelected ? 'bg-red-500/10 border-red-500/20 text-red-300' : 'bg-slate-900/25 border-slate-850 text-slate-400'}`}
                    >
                      {tr.isCorrect ? <Check className="w-4 h-4 mt-0.5" /> : wasSelected ? <X className="w-4 h-4 mt-0.5" /> : <Info className="w-4 h-4 mt-0.5" />}
                      <div>
                        <strong className="block font-serif text-white">{tr.trait} {tr.isCorrect ? '(Correct)' : '(Incorrect)'}</strong>
                        <span className="text-slate-300 block text-[11px] mt-0.5">{tr.description}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      }

      case 'retelling': {
        const itemsList = Array.isArray(currentAnswer) 
          ? currentAnswer 
          : (task as any).items || [];

        return (
          <div className="space-y-4 font-sans" id={`retelling-task-${task.id}`}>
            <p className="text-xs text-[#4A9EAD] font-mono tracking-widest uppercase mb-4">
              ★ Reorder the fables recap summary sentences into correct sequential chronology:
            </p>

            <div className="space-y-3">
              {itemsList.map((item: any, idx: number) => {
                const isCorrectPosition = isChecked && item.correctOrder === idx;
                
                let borderStyle = 'border-fairy-gold/15 bg-slate-900/60';
                if (isChecked) {
                  borderStyle = isCorrectPosition 
                    ? 'border-emerald-500/50 bg-emerald-950/20 text-emerald-400 font-medium' 
                    : 'border-red-500/50 bg-red-950/20 text-red-400';
                }

                return (
                  <div 
                    key={item.id} 
                    className={`flex items-center gap-3.5 p-3.5 rounded-xl border text-xs leading-relaxed transition-all ${borderStyle}`}
                  >
                    <div className="w-6 h-6 rounded-full bg-slate-800 border border-fairy-gold/25 flex items-center justify-center font-mono font-bold text-slate-300">
                      {idx + 1}
                    </div>

                    <p className="flex-1 text-slate-200 text-xs">{item.text}</p>

                    {!isChecked && (
                      <div className="flex flex-col gap-1">
                        <button
                          disabled={idx === 0}
                          onClick={() => moveRetellingItem(idx, 'up')}
                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-300 cursor-pointer"
                          title="Move sentence up"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          disabled={idx === itemsList.length - 1}
                          onClick={() => moveRetellingItem(idx, 'down')}
                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-300 cursor-pointer"
                          title="Move sentence down"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {isChecked && (
                      <div className="shrink-0">
                        {isCorrectPosition ? (
                          <Check className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <div className="text-right">
                            <X className="w-4 h-4 text-red-400 inline" />
                            <span className="block text-[9px] text-[#4A9EAD] font-mono font-bold mt-0.5">Correct: #{item.correctOrder + 1}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        );
      }

      case 'creative-text': {
        const val = currentAnswer || '';
        const pl = (task as any).placeholder || 'Expand the story here...';
        const minWords = (task as any).minWords || 10;
        const currentCount = getWordCount(val);

        return (
          <div className="space-y-4" id={`creative-${task.id}`}>
            <p className="text-[#4A9EAD] text-xs font-mono tracking-wide uppercase mb-2">
              ★ Creative Task Instruction:
            </p>
            <p className="text-slate-100 italic font-serif leading-relaxed text-sm md:text-base mb-4">
              "{ (task as any).instruction }"
            </p>

            <textarea
              disabled={isChecked}
              value={val}
              onChange={(e) => onAnswerChange(task.id, e.target.value)}
              placeholder={pl}
              className="w-full h-32 bg-slate-900 border border-fairy-gold/25 rounded-2xl p-4 text-xs md:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-fairy-gold leading-relaxed font-sans"
            />

            <div className="flex justify-between items-center text-xs font-mono text-slate-500">
              <span>Characters: {val.length}</span>
              <span className={currentCount >= minWords ? 'text-emerald-400 font-bold' : 'text-fairy-gold'}>
                Words: {currentCount} / {minWords} required
              </span>
            </div>

            {isChecked && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs p-3.5 rounded-xl leading-relaxed">
                <span className="font-bold block font-mono">🏆 Creative Merit Points Unlocked:</span>
                <span>Writing creative extensions expands your imaginative reasoning and language logic. Your response is officially submitted for diagnostic assessment!</span>
              </div>
            )}
          </div>
        );
      }

      default:
        return <p>Fallback: Task loading.</p>;
    }
  };

  return (
    <div className="max-w-4xl w-full flex flex-col justify-center items-center py-6 px-4 md:px-6 z-20 flex-1 relative select-none" id="pre-post-card">
      
      {/* Decorative medieval-feeling story scroll framing */}
      <div className="w-full bg-fairy-navy-light/95 border-2 border-fairy-gold/50 rounded-3xl p-6 md:p-10 shadow-2xl relative">
        
        {/* Sparkle decorative icons in the corner */}
        <div className="absolute top-4 right-4 text-fairy-gold animate-pulse">
          <Sparkles className="w-5 h-5" />
        </div>

        {/* Task category index badge */}
        <div className="flex justify-between items-center bg-slate-900/85 py-1.5 px-3.5 rounded-xl border border-slate-800 text-xs font-mono mb-6 max-w-max">
          <span className="text-fairy-gold font-bold mr-3 uppercase text-[10px]">
            {task.skill === 'MAIN_IDEA' ? 'Main Idea ID' : task.skill.replace('_', ' ')}
          </span>
          <span className="text-slate-500 border-l border-slate-800 pl-3">
            Task {taskIndex + 1} of {totalTaskCount}
          </span>
        </div>

        {/* Major question title text */}
        <h2 className="font-serif text-xl md:text-2xl font-bold text-fairy-cream tracking-wide mb-2">
          {task.title}
        </h2>
        
        {task.type !== 'text-warmup' && task.type !== 'creative-text' && (
          <p className="text-xs text-slate-400 leading-relaxed mb-6">
            {task.instruction}
          </p>
        )}

        {/* Main interactive field */}
        <div className="border-t border-fairy-gold/10 pt-6" id="pre-post-render-box">
          {renderContent()}
        </div>

        {/* Footer actions inside the scroll container */}
        <div className="border-t border-fairy-gold/10 pt-6 mt-10 space-y-4">
          
          {/* Main big Verify action button */}
          {!isChecked ? (
            <button
              onClick={() => onCheckAnswer(task.id)}
              className="w-full flex items-center justify-center gap-2 bg-[#4A9EAD] hover:bg-white text-fairy-navy font-bold py-3.5 px-4 rounded-xl cursor-pointer transition-all active:scale-[0.98] shadow-md text-sm font-sans"
              id="btn-verify-answer"
            >
              Verify Answer
            </button>
          ) : (
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs text-center py-2.5 px-4 rounded-xl font-mono flex items-center justify-center gap-1.5">
              <Check className="w-4 h-4" /> Answer Verified & Logged!
            </div>
          )}

          {/* Stepper progress paging controls */}
          <div className="flex gap-3">
            <button
              disabled={taskIndex === 0}
              onClick={onPrevTask}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 border border-fairy-gold/15 hover:border-fairy-gold bg-transparent hover:bg-fairy-gold/5 text-xs text-fairy-gold rounded-xl cursor-pointer transition-all disabled:opacity-30 disabled:hover:bg-transparent"
              id="btn-scroll-prev"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </button>
            
            {taskIndex < totalTaskCount - 1 ? (
              <button
                disabled={!isChecked}
                onClick={onNextTask}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-fairy-gold hover:bg-white text-xs font-bold text-fairy-navy rounded-xl cursor-pointer transition-all disabled:opacity-40 disabled:hover:bg-fairy-gold disabled:hover:text-fairy-navy"
                id="btn-scroll-next"
              >
                Forward <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                disabled={!isChecked}
                onClick={onCompletePhase}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-500 hover:bg-white text-xs font-bold text-fairy-navy rounded-xl cursor-pointer transition-all disabled:opacity-45 disabled:hover:bg-emerald-500"
                id="btn-complete-phase"
              >
                Save & Proceed!
              </button>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
