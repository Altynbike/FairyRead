import { Tale, StudentTaskState } from '../types';
import { ArrowLeft, Lock, Unlock, Check, BookOpen, Clock, HelpCircle } from 'lucide-react';

interface TaleHeaderProps {
  tale: Tale;
  state: StudentTaskState;
  activePhase: 'pre' | 'while' | 'post';
  onPhaseChange: (phase: 'pre' | 'while' | 'post') => void;
  onExit: () => void;
}

export default function TaleHeader({ tale, state, activePhase, onPhaseChange, onExit }: TaleHeaderProps) {
  // Check unlock status for each step
  const preCompleted = state?.completedPhases?.pre ?? false;
  const whileCompleted = state?.completedPhases?.while ?? false;

  const phases = [
    {
      id: 'pre' as const,
      label: '1. Pre-Reading',
      info: 'Activate Knowledge & Vocabulary',
      unlocked: true,
      completed: preCompleted,
    },
    {
      id: 'while' as const,
      label: '2. While-Reading',
      info: 'Track Comp & Grammar',
      unlocked: preCompleted,
      completed: whileCompleted,
    },
    {
      id: 'post' as const,
      label: '3. Post-Reading',
      info: 'Reflect, Retell & Infer',
      unlocked: preCompleted && whileCompleted,
      completed: state?.completedPhases?.post ?? false,
    },
  ];

  return (
    <div className="w-full bg-fairy-navy-light border-b border-fairy-gold/20 py-4 px-4 md:px-8 flex flex-col gap-4 select-none z-30 relative shadow-md">
      {/* Top row: Left button and title */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        
        {/* Back button + title info */}
        <div className="flex items-center gap-4">
          <button
            onClick={onExit}
            className="p-2.5 rounded-xl border border-fairy-gold/20 hover:border-fairy-gold bg-fairy-navy hover:bg-fairy-navy-lighter text-fairy-gold transition-all duration-200 cursor-pointer active:scale-90 shadow-sm"
            title="Return to home catalog"
            id="btn-back-catalog"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] uppercase font-mono bg-fairy-teal/15 text-fairy-teal border border-fairy-teal/30 px-2.5 py-0.5 rounded-md font-bold">
                Theme: {tale.theme}
              </span>
              <span className="text-[10px] uppercase font-mono bg-slate-800 text-slate-300 border border-slate-755 px-2.5 py-0.5 rounded-md flex items-center gap-1">
                <Clock className="w-3 h-3" /> ~{tale.durationMinutes} min
              </span>
            </div>
            <h1 className="font-serif text-xl md:text-2xl font-bold text-fairy-cream mt-1 drop-shadow-sm">
              {tale.title}
            </h1>
          </div>
        </div>

        {/* Small pedagogical metadata info */}
        <div className="hidden lg:block bg-fairy-navy p-3 rounded-xl border border-fairy-gold/10 text-right max-w-[280px]">
          <span className="block text-[9px] text-slate-500 font-mono uppercase tracking-wider">Active Grammar Target</span>
          <span className="text-xs text-fairy-gold font-medium font-serif leading-tight">{tale.grammarFocus.split('(')[0]}</span>
        </div>
      </div>

      {/* Stepper progress */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-1" id="phase-stepper">
        {phases.map((ph) => {
          const isActive = activePhase === ph.id;
          
          let cardStyle = 'border-slate-800/80 bg-slate-900/40 text-slate-500';
          let indicatorElement = <Lock className="w-3.5 h-3.5 shrink-0" />;

          if (isActive) {
            cardStyle = 'border-fairy-gold shadow-md shadow-fairy-gold/5 bg-fairy-navy-lighter text-fairy-cream';
            indicatorElement = <Clock className="w-4 h-4 text-fairy-gold animate-pulse shrink-0" />;
          } else if (ph.completed) {
            cardStyle = 'border-emerald-600/50 bg-emerald-950/20 text-emerald-400 hover:border-emerald-500 hover:bg-emerald-950/30';
            indicatorElement = <Check className="w-4 h-4 text-emerald-400 shrink-0" />;
          } else if (ph.unlocked) {
            cardStyle = 'border-[#4A9EAD]/40 bg-[#4A9EAD]/5 text-slate-200 hover:border-[#4A9EAD] hover:bg-[#4A9EAD]/10';
            indicatorElement = <Unlock className="w-3.5 h-3.5 text-fairy-teal shrink-0" />;
          }

          return (
            <button
              key={ph.id}
              disabled={!ph.unlocked}
              onClick={() => onPhaseChange(ph.id)}
              className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all duration-200 ${cardStyle} ${ph.unlocked ? 'cursor-pointer' : 'cursor-not-allowed opacity-50'}`}
              id={`stepper-tab-${ph.id}`}
            >
              <div className="p-1.5 rounded-lg bg-black/20 flex items-center justify-center">
                {indicatorElement}
              </div>
              <div className="min-w-0">
                <span className="block text-xs font-bold leading-tight font-sans tracking-wide">
                  {ph.label}
                </span>
                <span className="block text-[10px] text-slate-400 truncate mt-0.5">
                  {ph.info}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
