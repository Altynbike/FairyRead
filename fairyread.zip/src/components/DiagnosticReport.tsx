import { SkillType, StudentTaskState, Tale } from '../types';
import { Award, CheckCircle, RefreshCw, ArrowLeft, ArrowRight, BookOpen, AlertCircle, Info, ThumbsUp } from 'lucide-react';
import { motion } from 'motion/react';

interface DiagnosticReportProps {
  tale: Tale;
  state: StudentTaskState;
  completedTaleIds: string[];
  tales: Tale[];
  onBackToHome: () => void;
  onTryNextTale: (nextTaleId: string) => void;
}

export default function DiagnosticReport({
  tale,
  state,
  completedTaleIds,
  tales,
  onBackToHome,
  onTryNextTale,
}: DiagnosticReportProps) {
  const totalScore = state.score ?? 0;
  const skillScores = state.skillScores ?? {
    MAIN_IDEA: 0,
    DETAIL_RETRIEVAL: 0,
    SEQUENCING: 0,
    INFERENCE: 0,
    VOCABULARY: 0,
  };

  // Determine Proficiency Badge
  let badgeLabel = 'LOW';
  let badgeColor = 'bg-red-500/15 text-red-400 border-red-500/30';
  let badgeDesc = "Let's practice more. Re-read the story and try to find where you made mistakes.";
  let badgeAccent = 'text-red-400';

  if (totalScore >= 80) {
    badgeLabel = 'HIGH';
    badgeColor = 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
    badgeDesc = 'Excellent reading skills! You showed outstanding lexical, syntactic, and reasoning values.';
    badgeAccent = 'text-emerald-400';
  } else if (totalScore >= 60) {
    badgeLabel = 'MEDIUM';
    badgeColor = 'bg-fairy-gold/15 text-fairy-gold border-fairy-gold/30';
    badgeDesc = 'Good progress! Keep going. You understand the core actions but can master details further.';
    badgeAccent = 'text-fairy-gold';
  }

  // Horizontal skills data configuration
  const skillsConfig: { label: string; skillKey: SkillType; max: number }[] = [
    { label: 'Main Idea Identification', skillKey: 'MAIN_IDEA', max: 20 },
    { label: 'Detail Retrieval', skillKey: 'DETAIL_RETRIEVAL', max: 20 },
    { label: 'Sequencing / Event Order', skillKey: 'SEQUENCING', max: 20 },
    { label: 'Inference', skillKey: 'INFERENCE', max: 20 },
    { label: 'Vocabulary in Context', skillKey: 'VOCABULARY', max: 20 },
  ];

  // Specific pedagogical advice map for low-scoring skills (< 14)
  const adviceList: { key: SkillType; threshold: number; text: string }[] = [
    {
      key: 'MAIN_IDEA',
      threshold: 14,
      text: 'To improve your Main Idea skills, look at headings, initial paragraphs, and the title before detail reading. It helps form general concept prediction.'
    },
    {
      key: 'DETAIL_RETRIEVAL',
      threshold: 14,
      text: 'To improve Detail Retrieval, try scanning (searching without reading every line) for names, locations, numbers, or specific actions mentioned in the prompt.'
    },
    {
      key: 'SEQUENCING',
      threshold: 14,
      text: 'To master Sequencing, connect events by watching for sequencing transition words such as "First, Then, Suddenly, Afterwards, At Last, In the Morning".'
    },
    {
      key: 'INFERENCE',
      threshold: 14,
      text: 'To master Inference, ask: "Why did they choose that? What was their feeling?" Try to look beyond the literal words to grasp character motives.'
    },
    {
      key: 'VOCABULARY',
      threshold: 14,
      text: 'To grow Vocabulary in Context, make sure to click on highlighted gold vocab items in the story text to review definitions and Kazakh equivalents during reading.'
    }
  ];

  // Filter recommendations based on student performance
  const recommendations = adviceList.filter(adv => skillScores[adv.key] < adv.threshold);

  // Find next tale that isn't completed
  const nextTalesToOffer = tales.filter(t => t.id !== tale.id && !completedTaleIds.includes(t.id));

  // Circular calculations for progress ring
  const strokeDashoffset = 339.292 - (339.292 * totalScore) / 100;

  return (
    <div className="max-w-4xl w-full bg-fairy-navy-light/40 backdrop-blur-md border border-fairy-gold/25 rounded-3xl p-6 md:p-10 shadow-2xl z-20 my-10 animate-fade-in text-slate-200 select-none">
      
      {/* Title block */}
      <div className="text-center mb-8 border-b border-fairy-gold/10 pb-6">
        <span className="text-xs font-mono text-fairy-gold uppercase tracking-widest bg-fairy-gold/10 px-3 py-1 rounded-full border border-fairy-gold/20">
          Diagnostic Evaluation Report
        </span>
        <h2 className="font-serif text-3xl md:text-4xl font-bold text-fairy-cream mt-3">
          Completed: {tale.title}
        </h2>
        <p className="text-xs text-slate-400 mt-1 font-mono">
          Kazakhstan Grade 7 EFL Reading Skills Assessment System
        </p>
      </div>

      {/* Main Stats (Circular ring + Badge card) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center justify-center mb-10">
        
        {/* Ring (left-block) */}
        <div className="col-span-1 md:col-span-5 flex flex-col items-center">
          <div className="relative w-44 h-44 flex items-center justify-center">
            
            {/* SVG Ring */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
              {/* Under-ring */}
              <circle
                cx="60"
                cy="60"
                r="54"
                className="fill-transparent stroke-fairy-navy-lighter"
                strokeWidth="8"
              />
              {/* Highlight-ring */}
              <motion.circle
                cx="60"
                cy="60"
                r="54"
                className={`fill-transparent ${totalScore >= 80 ? 'stroke-emerald-400' : totalScore >= 60 ? 'stroke-fairy-gold' : 'stroke-red-400'} transition-all`}
                strokeWidth="8"
                strokeDasharray="339.292"
                initial={{ strokeDashoffset: 339.292 }}
                animate={{ strokeDashoffset }}
                transition={{ duration: 1.2, ease: 'easeOut' }}
                strokeLinecap="round"
              />
            </svg>

            {/* Inner text score */}
            <div className="absolute text-center">
              <span className="block text-4xl font-serif font-bold text-fairy-cream mt-1">
                {totalScore}
              </span>
              <span className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                out of 100
              </span>
            </div>
          </div>
          <span className="text-xs italic text-slate-400 mt-2">Overall Comprehension Score</span>
        </div>

        {/* Badge Card (right-block) */}
        <div className="col-span-1 md:col-span-7 bg-fairy-navy-lighter/30 border border-fairy-gold/15 rounded-2xl p-6 h-full flex flex-col justify-center">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-sm font-mono uppercase text-slate-400">Proficiency Level:</span>
            <span className={`px-3 py-1 font-mono font-bold text-xs tracking-widest border rounded px-3 py-1 ${badgeColor}`}>
              ● {badgeLabel}
            </span>
          </div>

          <h3 className={`font-serif text-xl font-bold mb-2 ${badgeAccent}`}>
            {totalScore >= 80 ? 'Excellent performance!' : totalScore >= 60 ? 'Good work!' : 'Keep practicing!'}
          </h3>
          <p className="text-slate-300 text-sm leading-relaxed mb-4">
            {badgeDesc}
          </p>

          <div className="bg-fairy-navy-card rounded-lg p-3 border border-fairy-gold/5 flex gap-2 text-xs text-slate-400 leading-relaxed">
            <Info className="w-4 h-4 text-fairy-teal shrink-0 mt-0.5" />
            <span>This rating is calibrated to B1 standard learning expectations under international CEFR diagnostic rules for secondary students.</span>
          </div>
        </div>

      </div>

      {/* Skills breakdown bars */}
      <div className="mb-10 bg-fairy-navy-lighter/10 border border-fairy-gold/10 rounded-2xl p-6">
        <h3 className="font-serif text-xl font-bold text-fairy-cream mb-6 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-fairy-gold" /> Reading Skill Breakdown (0–20 Scale)
        </h3>

        <div className="space-y-5">
          {skillsConfig.map(({ label, skillKey, max }) => {
            const score = skillScores[skillKey];
            const pct = (score / max) * 100;
            
            // color mapping
            let barColor = 'bg-red-400';
            let textColor = 'text-red-400';
            if (score >= 16) {
              barColor = 'bg-emerald-400';
              textColor = 'text-emerald-400';
            } else if (score >= 11) {
              barColor = 'bg-fairy-gold';
              textColor = 'text-fairy-gold';
            }

            return (
              <div key={skillKey} className="space-y-1">
                {/* Score meta */}
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-slate-300 font-medium">{label}</span>
                  <span className={`font-bold ${textColor}`}>{score} / {max} ({pct.toFixed(0)}%)</span>
                </div>
                {/* Horizontal bar back */}
                <div className="w-full h-2.5 bg-fairy-navy-light rounded-full overflow-hidden border border-fairy-gold/5">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 1, ease: 'easeOut' }}
                    className={`h-full rounded-full ${barColor}`}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Dynamic Pedagogical Feedback Advice section */}
      <div className="mb-10">
        <h3 className="font-serif text-xl font-bold text-fairy-cream mb-4 flex items-center gap-2">
          <ThumbsUp className="w-5 h-5 text-fairy-teal" /> Personal Learning Recommendations
        </h3>
        
        {recommendations.length === 0 ? (
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4 text-sm text-emerald-400 flex gap-3">
            <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold">Fantastic!</strong> You scored high across all reading skill dimensions. You are ready to try more difficult tales or proceed to advanced reading levels with great confidence!
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {recommendations.map((rec, idx) => (
              <div 
                key={idx} 
                className="bg-fairy-navy-lighter/35 border border-fairy-gold/10 rounded-xl p-4 text-xs md:text-sm flex gap-3 hover:border-fairy-gold/25 transition-colors"
              >
                <AlertCircle className="w-5 h-5 text-fairy-gold shrink-0 mt-0.5" />
                <div>
                  <strong className="text-fairy-gold uppercase tracking-wider block font-mono text-xs mb-1">
                    Guidance for {rec.key === 'VOCABULARY' ? 'Vocabulary in Context' : rec.key.replace('_', ' ')}:
                  </strong>
                  <span className="text-slate-300">{rec.text}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Navigation action rows */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 pt-6 border-t border-fairy-gold/10">
        <button
          onClick={onBackToHome}
          className="w-full md:w-auto flex items-center justify-center gap-2 py-3 px-5 border border-fairy-gold/25 hover:border-fairy-gold rounded-xl font-medium text-sm text-fairy-gold bg-transparent hover:bg-fairy-gold/5 transition-all cursor-pointer active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" /> Return to Tale Selector
        </button>

        {/* Suggest next tale if there is one */}
        {nextTalesToOffer.length > 0 ? (
          <button
            onClick={() => onTryNextTale(nextTalesToOffer[0].id)}
            className="w-full md:w-auto flex items-center justify-center gap-2 py-3 px-6 bg-fairy-gold text-fairy-navy font-bold rounded-xl hover:bg-white hover:text-fairy-navy transition-all cursor-pointer shadow-lg hover:shadow-fairy-gold/20 active:scale-95 animate-pulse"
          >
            Try Next Tale: {nextTalesToOffer[0].title} <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs px-4 py-2.5 rounded-xl font-mono">
            <CheckCircle className="w-4 h-4" /> You have read all library fables! Excellent job!
          </div>
        )}
      </div>

    </div>
  );
}
