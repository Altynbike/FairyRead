export type SkillType = 'MAIN_IDEA' | 'DETAIL_RETRIEVAL' | 'SEQUENCING' | 'INFERENCE' | 'VOCABULARY';

export interface VocabWord {
  word: string;
  definition: string;
  example: string;
  kazakh?: string; // Additional cultural connection for Kazakh EFL context
}

export interface TaskOption {
  value: string;
  label: string;
}

export interface MatchingPair {
  id: string;
  word: string;
  definition: string;
}

export interface DragItem {
  id: string;
  text: string;
  correctOrder: number; // 0-indexed correct order
}

export type TaskType = 
  | 'prediction' 
  | 'matching' 
  | 'text-warmup' 
  | 'prediction-slider'
  | 'true-false'
  | 'sequencing'
  | 'detail-mc'
  | 'detail-short'
  | 'vocab-context'
  | 'fill-in-blank'
  | 'grammar-mc'
  | 'inference-mc'
  | 'moral-mc'
  | 'mind-map'
  | 'retelling'
  | 'comparison-mc'
  | 'creative-text';

export interface BaseTask {
  id: string;
  type: TaskType;
  skill: SkillType;
  title: string;
  instruction: string;
  points: number; // weight of this specific task
}

export interface PredictionTask extends BaseTask {
  type: 'prediction';
  placeholder: string;
}

export interface MatchingTask extends BaseTask {
  type: 'matching';
  pairs: MatchingPair[];
}

export interface WarmupTask extends BaseTask {
  type: 'text-warmup';
  question: string;
  placeholder: string;
}

export interface PredictionSliderTask extends BaseTask {
  type: 'prediction-slider';
  options: {
    value: string;
    label: string;
    description: string;
  }[];
}

export interface TrueFalseStatement {
  id: string;
  statement: string;
  isTrue: boolean;
  explanation: string;
}

export interface TrueFalseTask extends BaseTask {
  type: 'true-false';
  statements: TrueFalseStatement[];
}

export interface SequencingTask extends BaseTask {
  type: 'sequencing';
  items: DragItem[];
}

export interface MultipleChoiceTask extends BaseTask {
  type: 'detail-mc' | 'grammar-mc' | 'inference-mc' | 'moral-mc' | 'comparison-mc';
  question: string;
  options: {
    value: string;
    label: string;
    isCorrect: boolean;
    feedback: string;
  }[];
}

export interface ShortAnswerTask extends BaseTask {
  type: 'detail-short';
  question: string;
  correctAnswers: string[]; // Allowed exact matches (case-insensitive)
  placeholder: string;
}

export interface VocabContextTask extends BaseTask {
  type: 'vocab-context';
  passage: string;
  question: string;
  correctWord: string; // The word student must identify/click
  options: string[]; // A set of candidate words to click
}

export interface FillInBlankTask extends BaseTask {
  type: 'fill-in-blank';
  textWithBlanks: string; // "The boy was [blank1] because of the cold. He had to [blank2] his finger."
  blanks: {
    key: string;
    correctAnswer: string;
    options: string[]; // Dropdown word choices
  }[];
}

export interface MindMapTask extends BaseTask {
  type: 'mind-map';
  characterName: string;
  traits: {
    trait: string;
    isCorrect: boolean;
    description: string;
  }[];
  requiredCount: number;
}

export interface RetellingTask extends BaseTask {
  type: 'retelling';
  items: DragItem[];
}

export interface CreativeTextTask extends BaseTask {
  type: 'creative-text';
  prompt?: string;
  placeholder: string;
  minWords: number;
}

export type Task =
  | PredictionTask
  | MatchingTask
  | WarmupTask
  | PredictionSliderTask
  | TrueFalseTask
  | SequencingTask
  | MultipleChoiceTask
  | ShortAnswerTask
  | VocabContextTask
  | FillInBlankTask
  | MindMapTask
  | CreativeTextTask
  | RetellingTask;

export interface TaleSection {
  id: string;
  title: string;
  content: string; // Story content chunk
  vocabularyHighlights: {
    word: string;
    definition: string;
    kazakh?: string;
  }[];
}

export interface Tale {
  id: string;
  title: string;
  theme: string;
  icon: string;
  teaser: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  durationMinutes: number;
  grammarFocus: string;
  keyVocabulary: string[];
  vocabularyList: VocabWord[];
  sections: TaleSection[];
  
  // Phases
  preReadingTasks: Task[];
  whileReadingTasks: Task[];
  postReadingTasks: Task[];
}

export interface StudentAnswers {
  [taskId: string]: any; // Store answers: open-ended text, indices, matching lists, etc.
}

export interface StudentTaskState {
  answers: StudentAnswers;
  completedPhases: {
    pre: boolean;
    while: boolean;
    post: boolean;
  };
  score?: number; // out of 100
  skillScores?: {
    [key in SkillType]: number; // out of 20
  };
  submittedDate?: string;
}

// Stores overall student progress for all tales
export interface StudentRegistry {
  [taleId: string]: StudentTaskState;
}
