import { useState, useEffect } from 'react';
import { talesData } from './data';
import { StudentRegistry, StudentAnswers, SkillType, Tale } from './types';
import MainLanding from './components/MainLanding';
import TaleHeader from './components/TaleHeader';
import SplitReader from './components/SplitReader';
import PrePostReader from './components/PrePostReader';
import DiagnosticReport from './components/DiagnosticReport';
import { BookOpen, Sparkles, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Scoring Function aligning to 20-pts-per-skill Kazakhstan Pedagogy Framework
function calculateTaleScores(tale: Tale, answers: StudentAnswers) {
  const scoreMap: { [key in SkillType]: { totalWeight: number; earnedWeight: number } } = {
    MAIN_IDEA: { totalWeight: 0, earnedWeight: 0 },
    DETAIL_RETRIEVAL: { totalWeight: 0, earnedWeight: 0 },
    SEQUENCING: { totalWeight: 0, earnedWeight: 0 },
    INFERENCE: { totalWeight: 0, earnedWeight: 0 },
    VOCABULARY: { totalWeight: 0, earnedWeight: 0 },
  };

  const allTasks = [...tale.preReadingTasks, ...tale.whileReadingTasks, ...tale.postReadingTasks];

  allTasks.forEach(task => {
    const ans = answers[task.id];
    let pointsRatio = 0; // 0.0 to 1.0

    if (ans !== undefined && ans !== null) {
      if (task.type === 'prediction' || task.type === 'text-warmup' || task.type === 'creative-text') {
        const textVal = String(ans).trim();
        // Effort-based: any length >= 10 characters or 3 words is 100% correct
        pointsRatio = textVal.length >= 10 ? 1 : 0.5;
      } else if (task.type === 'prediction-slider') {
        pointsRatio = ans ? 1 : 0;
      } else if (task.type === 'true-false') {
        const statements = task.statements || [];
        const correctCount = statements.filter(st => {
          const userVal = ans[st.id];
          return userVal !== undefined && userVal === st.isTrue;
        }).length;
        pointsRatio = statements.length > 0 ? correctCount / statements.length : 0;
      } else if (task.type === 'matching') {
        const pairs = task.pairs || [];
        const pairsMatched = ans.pairsMatched || {};
        const correctCount = pairs.filter(p => pairsMatched[p.id] === p.id).length;
        pointsRatio = pairs.length > 0 ? correctCount / pairs.length : 0;
      } else if (task.type === 'sequencing' || (task as any).type === 'retelling') {
        const items = (task as any).items || [];
        const correctCount = items.filter((item, index) => {
          const userItem = ans[index];
          return userItem && userItem.id === item.id;
        }).length;
        pointsRatio = items.length > 0 ? correctCount / items.length : 0;
      } else if (task.type === 'detail-mc' || task.type === 'grammar-mc' || task.type === 'inference-mc' || task.type === 'moral-mc' || task.type === 'comparison-mc') {
        const correctOpt = task.options.find(o => o.isCorrect);
        pointsRatio = correctOpt && ans === correctOpt.value ? 1 : 0;
      } else if (task.type === 'detail-short') {
        const correctList = task.correctAnswers.map(c => c.toLowerCase().trim());
        pointsRatio = correctList.includes(String(ans).toLowerCase().trim()) ? 1 : 0;
      } else if (task.type === 'vocab-context') {
        pointsRatio = ans === task.correctWord ? 1 : 0;
      } else if (task.type === 'fill-in-blank') {
        const blanks = task.blanks || [];
        const correctCount = blanks.filter(bk => {
          const userVal = ans[bk.key];
          return userVal !== undefined && String(userVal).trim() === String(bk.correctAnswer).trim();
        }).length;
        pointsRatio = blanks.length > 0 ? correctCount / blanks.length : 0;
      } else if (task.type === 'mind-map') {
        const traits = task.traits || [];
        const checkedTraits = ans || [];
        const correctCount = traits.filter(tr => tr.isCorrect && checkedTraits.includes(tr.trait)).length;
        pointsRatio = task.requiredCount > 0 ? correctCount / task.requiredCount : 0;
      }
    }

    // Accumulate total possible and achieved score ratios
    scoreMap[task.skill].totalWeight += 1;
    scoreMap[task.skill].earnedWeight += pointsRatio;
  });

  // Translate percentages to exactly 20 points maximum per key skill
  const skillScores: { [key in SkillType]: number } = {
    MAIN_IDEA: 0,
    DETAIL_RETRIEVAL: 0,
    SEQUENCING: 0,
    INFERENCE: 0,
    VOCABULARY: 0,
  };

  let finalSum = 0;
  Object.keys(scoreMap).forEach(key => {
    const skill = key as SkillType;
    const item = scoreMap[skill];
    const skillVal = item.totalWeight > 0 ? (item.earnedWeight / item.totalWeight) * 20 : 0;
    const roundedSkill = Math.min(20, Math.round(skillVal));
    skillScores[skill] = roundedSkill;
    finalSum += roundedSkill;
  });

  // Overall sum is exact sum of the 5 rounded categories (Locked between 0-100)
  const score = Math.min(100, Math.max(0, finalSum));

  return { score, skillScores };
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'reading' | 'results'>('home');
  const [selectedTaleId, setSelectedTaleId] = useState<string | null>(null);
  const [currentPhase, setCurrentPhase] = useState<'pre' | 'while' | 'post'>('pre');
  const [currentTaskIndex, setCurrentTaskIndex] = useState<number>(0);

  // Persistence registry state loaded from localstorage
  const [registry, setRegistry] = useState<StudentRegistry>({});

  // Tentative and verified answers for active fables, is persistent locally
  const [tempAnswers, setTempAnswers] = useState<StudentAnswers>({});
  const [checkedTasks, setCheckedTasks] = useState<{ [taskId: string]: boolean }>({});

  // Sync state with localStorage on startup
  useEffect(() => {
    const stored = localStorage.getItem('fairyread_student_progress_v1');
    if (stored) {
      try {
        setRegistry(JSON.parse(stored));
      } catch (err) {
        console.error('Error reading localStorage fables progress', err);
      }
    }
  }, []);

  // Sync back to localstorage whenever registry updates
  const updateRegistryAndSave = (nextRegistry: StudentRegistry) => {
    setRegistry(nextRegistry);
    localStorage.setItem('fairyread_student_progress_v1', JSON.stringify(nextRegistry));
  };

  // Find active tale
  const activeTale = talesData.find(t => t.id === selectedTaleId);

  // Get current active task list
  const getActiveTasksList = (tale: Tale, phase: 'pre' | 'while' | 'post') => {
    if (phase === 'pre') return tale.preReadingTasks;
    if (phase === 'while') return tale.whileReadingTasks;
    return tale.postReadingTasks;
  };

  // Select tale starting flow
  const handleSelectTale = (taleId: string) => {
    const tale = talesData.find(t => t.id === taleId);
    if (!tale) return;

    setSelectedTaleId(taleId);
    const existingState = registry[taleId];

    // If tale is finished, directly render diagnostic results board
    const finished = existingState?.completedPhases?.pre && existingState?.completedPhases?.while && existingState?.completedPhases?.post;
    if (finished) {
      setCurrentPage('results');
    } else {
      // Restore wherever we left off
      const completedPre = existingState?.completedPhases?.pre ?? false;
      const completedWhile = existingState?.completedPhases?.while ?? false;

      let startingPhase: 'pre' | 'while' | 'post' = 'pre';
      if (completedWhile) startingPhase = 'post';
      else if (completedPre) startingPhase = 'while';

      setCurrentPhase(startingPhase);
      setCurrentTaskIndex(0);
      setTempAnswers(existingState?.answers ?? {});
      
      // Determine checked state for restored answers
      const restoredChecked: { [tid: string]: boolean } = {};
      const restoredAnswers = existingState?.answers ?? {};
      Object.keys(restoredAnswers).forEach(tid => {
        restoredChecked[tid] = true; // All previously saved progression items are locked & checked
      });
      setCheckedTasks(restoredChecked);
      
      setCurrentPage('reading');
    }
  };

  // Handles updating temporary action sheets
  const handleAnswerChange = (taskId: string, val: any) => {
    setTempAnswers(prev => ({
      ...prev,
      [taskId]: val
    }));
  };

  // Check answers instantly
  const handleCheckAnswer = (taskId: string) => {
    setCheckedTasks(prev => ({
      ...prev,
      [taskId]: true
    }));

    // Save progressively to registry, preserving achievements
    if (selectedTaleId) {
      const existingState = registry[selectedTaleId] || {
        answers: {},
        completedPhases: { pre: false, while: false, post: false }
      };

      const updatedAnswers = {
        ...existingState.answers,
        ...tempAnswers,
        [taskId]: tempAnswers[taskId]
      };

      const nextRegistry = {
        ...registry,
        [selectedTaleId]: {
          ...existingState,
          answers: updatedAnswers
        }
      };
      updateRegistryAndSave(nextRegistry);
    }
  };

  // Steps controls
  const handlePrevTask = () => {
    if (currentTaskIndex > 0) {
      setCurrentTaskIndex(currentTaskIndex - 1);
    }
  };

  const handleNextTask = () => {
    if (activeTale) {
      const tasks = getActiveTasksList(activeTale, currentPhase);
      if (currentTaskIndex < tasks.length - 1) {
        setCurrentTaskIndex(currentTaskIndex + 1);
      }
    }
  };

  // Handles completing Pre/While/Post Phases
  const handleCompleteActivePhase = () => {
    if (!selectedTaleId || !activeTale) return;

    const existingState = registry[selectedTaleId] || {
      answers: {},
      completedPhases: { pre: false, while: false, post: false }
    };

    const nextCompleted = { ...existingState.completedPhases };
    nextCompleted[currentPhase] = true;

    // Build the consolidated list of answers for safety
    const consolidatedAnswers = {
      ...existingState.answers,
      ...tempAnswers
    };

    let nextPhaseToSet = currentPhase;
    let nextPageIndex = currentPage;

    if (currentPhase === 'pre') {
      nextPhaseToSet = 'while';
      setCurrentPhase('while');
      setCurrentTaskIndex(0);
    } else if (currentPhase === 'while') {
      nextPhaseToSet = 'post';
      setCurrentPhase('post');
      setCurrentTaskIndex(0);
    } else {
      // Finished all fables! Compute diagnostic results
      const { score, skillScores } = calculateTaleScores(activeTale, consolidatedAnswers);
      
      const updatedState = {
        answers: consolidatedAnswers,
        completedPhases: { pre: true, while: true, post: true },
        score,
        skillScores,
        submittedDate: new Date().toISOString()
      };

      const nextRegistry = {
        ...registry,
        [selectedTaleId]: updatedState
      };
      updateRegistryAndSave(nextRegistry);
      setCurrentPage('results');
      return;
    }

    // Save intermediate progress back to registry
    const nextRegistry = {
      ...registry,
      [selectedTaleId]: {
        answers: consolidatedAnswers,
        completedPhases: nextCompleted
      }
    };
    updateRegistryAndSave(nextRegistry);
  };

  // Step Header navigation clicker
  const handleStepperClickChange = (phase: 'pre' | 'while' | 'post') => {
    setCurrentPhase(phase);
    setCurrentTaskIndex(0);
  };

  // Return to homepage
  const handleExitToHome = () => {
    setCurrentPage('home');
    setSelectedTaleId(null);
  };

  // Reset entire platform progression
  const handleResetProgressAll = () => {
    localStorage.removeItem('fairyread_student_progress_v1');
    setRegistry({});
    setTempAnswers({});
    setCheckedTasks({});
    setCurrentPage('home');
    setSelectedTaleId(null);
  };

  const handleTryNextTale = (nextTaleId: string) => {
    handleSelectTale(nextTaleId);
  };

  // Extract completed tale IDs list
  const completedTaleIds = Object.keys(registry).filter(tid => {
    const s = registry[tid];
    return s.completedPhases.pre && s.completedPhases.while && s.completedPhases.post;
  });

  return (
    <div className="min-h-screen bg-fairy-navy text-slate-100 flex flex-col font-sans select-none relative" id="applet-viewport">
      
      {/* Universal Floating Header branding block during worksheets */}
      {currentPage !== 'home' && (
        <header className="bg-fairy-navy-light/95 backdrop-blur-md px-6 py-2.5 border-b border-fairy-gold/10 flex justify-between items-center z-40 select-none">
          <button 
            onClick={handleExitToHome}
            className="flex items-center gap-2 font-serif text-lg md:text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-fairy-cream to-fairy-gold hover:opacity-85 transition-opacity cursor-pointer active:scale-95"
          >
            <BookOpen className="w-5 h-5 text-fairy-gold shrink-0" /> FairyRead
          </button>
          
          <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Grade 7 EFL • Learning Lab</span>
          </div>
        </header>
      )}

      {/* Main layout contents */}
      <main className="flex-1 flex flex-col items-center">
        <AnimatePresence mode="wait">
          {currentPage === 'home' && (
            <motion.div
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="w-full flex-1 flex flex-col"
            >
              <MainLanding
                tales={talesData}
                registry={registry}
                onSelectTale={handleSelectTale}
                onResetProgress={handleResetProgressAll}
              />
            </motion.div>
          )}

          {currentPage === 'reading' && activeTale && (
            <motion.div
              key="reading-sheet"
              initial={{ opacity: 0, scale: 0.99 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="w-full flex-1 flex flex-col items-center"
            >
              <TaleHeader
                tale={activeTale}
                state={registry[activeTale.id] || { answers: {}, completedPhases: { pre: false, while: false, post: false } }}
                activePhase={currentPhase}
                onPhaseChange={handleStepperClickChange}
                onExit={handleExitToHome}
              />

              {/* Task layout differs by scroll split vs singular worksheet panel */}
              {currentPhase === 'while' ? (
                <SplitReader
                  tale={activeTale}
                  task={getActiveTasksList(activeTale, 'while')[currentTaskIndex]}
                  taskIndex={currentTaskIndex}
                  totalTaskCount={getActiveTasksList(activeTale, 'while').length}
                  tempAnswers={tempAnswers}
                  onAnswerChange={handleAnswerChange}
                  onPrevTask={handlePrevTask}
                  onNextTask={handleNextTask}
                  onCheckAnswer={handleCheckAnswer}
                  checkedTasks={checkedTasks}
                  onCompletePhase={handleCompleteActivePhase}
                />
              ) : (
                <PrePostReader
                  task={getActiveTasksList(activeTale, currentPhase)[currentTaskIndex]}
                  taskIndex={currentTaskIndex}
                  totalTaskCount={getActiveTasksList(activeTale, currentPhase).length}
                  tempAnswers={tempAnswers}
                  onAnswerChange={handleAnswerChange}
                  onPrevTask={handlePrevTask}
                  onNextTask={handleNextTask}
                  onCheckAnswer={handleCheckAnswer}
                  checkedTasks={checkedTasks}
                  onCompletePhase={handleCompleteActivePhase}
                />
              )}
            </motion.div>
          )}

          {currentPage === 'results' && activeTale && registry[activeTale.id] && (
            <motion.div
              key="diagnostic-board"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="w-full flex-1 flex justify-center items-center px-4"
            >
              <DiagnosticReport
                tale={activeTale}
                state={registry[activeTale.id]}
                completedTaleIds={completedTaleIds}
                tales={talesData}
                onBackToHome={handleExitToHome}
                onTryNextTale={handleTryNextTale}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Aesthetic glowing background details */}
      {currentPage !== 'home' && (
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[700px] rounded-full bg-fairy-gold/2 blur-[150px] pointer-events-none select-none z-0" />
      )}
    </div>
  );
}
