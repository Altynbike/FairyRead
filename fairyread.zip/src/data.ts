import { Tale } from './types';

export const talesData: Tale[] = [
  {
    id: 'hero-of-haarlem',
    title: 'The Little Hero of Haarlem',
    theme: 'HEROISM',
    icon: '⚓',
    teaser: 'A brave young boy named Hans saves his entire city from a terrible flood with a single finger.',
    difficulty: 'Medium',
    durationMinutes: 25,
    grammarFocus: 'Past Simple Irregular Verbs (find→found, give→gave, choose→chose, become→became, say→said, think→thought)',
    keyVocabulary: ['dyke', 'forefinger', 'keep out', 'trickle', 'bubble', 'great gap', 'feel numb', 'pale', 'whisper'],
    vocabularyList: [
      { word: 'dyke', definition: 'A long wall or embankment built to prevent flooding from the sea', example: 'The dyke keeps the water from covering the land.', kazakh: 'бөгет' },
      { word: 'forefinger', definition: 'The finger next to the thumb; also called index finger', example: 'Hans used his forefinger to stop the streaming water.', kazakh: 'сұқ саусақ' },
      { word: 'keep out', definition: 'To prevent something or someone from entering', example: 'The strong stone walls keep out the cold ocean waves.', kazakh: 'кіргізбеу' },
      { word: 'trickle', definition: 'To flow in a small, thin stream or in drops', example: 'A trickle of cold water escaped between the stones.', kazakh: 'жылжып ағу' },
      { word: 'bubble', definition: 'To form small bubbles of air or gas in a liquid, showing movement', example: 'The water began to bubble out of the small crack.', kazakh: 'көпіршу (пысылдау)' },
      { word: 'great gap', definition: 'A large opening, hole, or separation in a structure', example: 'If the small hole grows, it will become a great gap.', kazakh: 'үлкен саңылау' },
      { word: 'feel numb', definition: 'To lose sensation, physical feeling or movement, usually due to cold', example: 'Hans’s hand began to feel numb in the dark, cold night.', kazakh: 'жансыздану' },
      { word: 'pale', definition: 'Lacking color in the face, whitish, usually due to fear, illness, or cold', example: 'His face grew pale, but he refused to let go.', kazakh: 'бозару' },
      { word: 'whisper', definition: 'To speak very softly using one\'s breath, not vocal cords', example: '"I must stay strong," he whispered to himself.', kazakh: 'сыбырлау' }
    ],
    sections: [
      {
        id: 'haarlem-1',
        title: 'Section 1: The Land Below the Sea',
        content: `A long time ago, in Holland, there lived a boy named Hans. His father was the gatekeeper who opened and closed the great gates of the dykes. For you must know that in Holland, much of the land lies lower than the level of the sea. Only the great walls, called dykes, keep out the wild waves. If these dykes should break, the cold seawater would rush in and cover the houses, fields, and crops. Hans knew this very well, and his father always taught him to watch the dykes closely, because the lives of everyone in the city of Haarlem depended on them. One beautiful afternoon, when Hans was eight years old, his mother asked him to walk along the dyke to visit an old blind man and carry him some fresh bread. Hans gladly agreed, chose the path, and walked happily, thinking about how his little deed would cheer up his old friend.`,
        vocabularyHighlights: [
          { word: 'dyke', definition: 'A long wall or embankment built to prevent flooding from the sea', kazakh: 'бөгет' },
          { word: 'keep out', definition: 'To prevent something or someone from entering', kazakh: 'кіргізбеу' }
        ]
      },
      {
        id: 'haarlem-2',
        title: 'Section 2: The Dangerous Trickle',
        content: `Hans spent a lovely hour with the blind man, reading to him and sharing stories about school. But as the sun began to sink below the horizon, Hans knew he had to go home quickly. As he walked along the canal path, the sky grew thick with dark clouds. There was no one in sight. Suddenly, Hans heard a sound that made his heart beat faster. It was the sound of trickling water! He stopped and searched the dark side of the dyke. There, near the bottom, he found a tiny hole through which a thin stream of water was trickled. Already, the water was beginning to bubble out. Hans became pale with fear. He realized the danger immediately. If the water trickled and bubbled through, the hole would quickly get bigger, turning into a great gap, and the angry sea would flood the whole Haarlem and wash away the wheat crops!`,
        vocabularyHighlights: [
          { word: 'trickle', definition: 'To flow in a small, thin stream', kazakh: 'жылжып ағу' },
          { word: 'bubble', definition: 'To form small bubbles of air', kazakh: 'көпіршу' },
          { word: 'great gap', definition: 'A large opening, hole, or separation', kazakh: 'үлкен саңылау' },
          { word: 'pale', definition: 'Lacking color in the face', kazakh: 'бозару' }
        ]
      },
      {
        id: 'haarlem-3',
        title: 'Section 3: The Cold Night Guardian',
        content: `There was no time to run and get help. Hans looked around, but the road was completely empty. He knew that if he left, the dyke would break before he could return. So, Hans knelt down on the wet grass, took a deep breath, and pushed his forefinger into the tiny hole. To his relief, the cold water stopped flowing! He shouted for help, calling "Mother! Father! Somebody help!" but the wind carried his voice away. The night became pitch black and incredibly cold. Hans’s entire hand began to feel numb. The cold crept up his arm, and his teeth began to chatter. His muscles grew stiff, and he had to whisper words of courage to himself to keep from crying. "Holland will not be flooded while I am here!" he whispered. He thought of his warm bed, of his parents sleeping soundly, and of the innocent children in the town. For hours and hours, he held his finger tight inside the freezing wall.`,
        vocabularyHighlights: [
          { word: 'forefinger', definition: 'The index finger', kazakh: 'сұқ саусақ' },
          { word: 'feel numb', definition: 'To lose physical feeling due to cold', kazakh: 'жансыздану' },
          { word: 'whisper', definition: 'To speak very softly', kazakh: 'сыбырлау' }
        ]
      },
      {
        id: 'haarlem-4',
        title: 'Section 4: The Little Savior of Haarlem',
        content: `Morning finally came. The stars faded, and a light mist lay over the fields. Hans was nearly unconscious, trembling and frozen, but his stiff forefinger remained locked inside the dyke. Just after sunrise, a clergyman who was walking home along the path heard a weak, trembling whisper. He looked over the edge of the dyke and found the young boy huddled against the massive wall, crying out softly. "What in the world is the matter, child?" the clergyman cried. "I am keeping the water out!" Hans whispered, looking up pale and weak. "Tell them to come quickly!" The clergyman immediately ran to the village and gave the alarm. Soon, a crowd of men arrived with axes, shovels, and stones. They quickly repaired the leak and carried Hans back to his parents. The entire city of Haarlem rejoiced. Hans had saved them all, and to this day, he is remembered as the brave Little Hero of Haarlem.`,
        vocabularyHighlights: [
          { word: 'pale', definition: 'Whitish, lacking color', kazakh: 'бозару' },
          { word: 'whisper', definition: 'To speak softly', kazakh: 'сыбырлау' }
        ]
      }
    ],
    preReadingTasks: [
      {
        id: 'h-pre-1',
        type: 'prediction',
        skill: 'MAIN_IDEA',
        title: 'Prediction: The Face of Heroism',
        instruction: 'Look at the title "The Little Hero of Haarlem" and think about the word "Hero". What do you think a hero does in this story?',
        points: 5,
        placeholder: 'I think the story is about a young boy who...'
      },
      {
        id: 'h-pre-2',
        type: 'matching',
        skill: 'VOCABULARY',
        title: 'Vocabulary Preview: Protect the City',
        instruction: 'Match these key terms to their correct definitions before starting your reading journey.',
        points: 5,
        pairs: [
          { id: 'p1', word: 'dyke', definition: 'A long wall or wall-like structure built to keep out the sea water' },
          { id: 'p2', word: 'forefinger', definition: 'The index finger, which is located right next to the thumb' },
          { id: 'p3', word: 'trickle', definition: 'To flow slowly in a very thin stream or in single drops' },
          { id: 'p4', word: 'feel numb', definition: 'To lose sensation or feeling, especially when freezing cold' },
          { id: 'p5', word: 'whisper', definition: 'To speak extremely softly using your breath rather than your vocal cords' }
        ]
      },
      {
        id: 'h-pre-3',
        type: 'text-warmup',
        skill: 'INFERENCE',
        title: 'Warm-up: Real Courage',
        instruction: 'Answer this personal reflection question in 1 or 2 simple sentences.',
        points: 5,
        question: 'Have you ever done something brave, or helped someone when it was difficult? Write about your experience or what you think "bravery" means.',
        placeholder: 'To me, bravery means...'
      },
      {
        id: 'h-pre-4',
        type: 'prediction-slider',
        skill: 'MAIN_IDEA',
        title: 'Prediction Slider: Hans’s Challenge',
        instruction: 'Move the slider to choose what you think will be the main conflict Hans faces in this story.',
        points: 5,
        options: [
          { value: 'storm', label: '1. Sea Storm', description: 'A massive ocean storm destroys the harbor and Hans must rescue trapped fishermen.' },
          { value: 'leak', label: '2. A Dyke Leak', description: 'Hans discovers a critical leak in the dyke wall and must find a way to stop it alone.' },
          { value: 'monster', label: '3. Sea Dragon', description: 'A legendary creature rises from the deep ocean and Hans must protect his town.' }
        ]
      }
    ],
    whileReadingTasks: [
      {
        id: 'h-while-1',
        type: 'true-false',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Comprehension: Fact-Checking Haarlem',
        instruction: 'Decide whether each statement is True or False based on Sections 1 and 2.',
        points: 4,
        statements: [
          { id: 'tf1', statement: 'Hans\'s father worked as a baker in the city of Haarlem.', isTrue: false, explanation: 'Hans\'s father was the gatekeeper of the dykes.' },
          { id: 'tf2', statement: 'Much of the land in Holland lies lower than the sea level.', isTrue: true, explanation: 'Yes, the text explains that the land is lower than the sea level, which is why dykes are extremely important.' },
          { id: 'tf3', statement: 'Hans went to visit a deaf blacksmith to bring him apple pies.', isTrue: false, explanation: 'Hans went to visit an old blind man to carry him some fresh bread.' },
          { id: 'tf4', statement: 'Hans found a small leak in the wall as the sun was setting.', isTrue: true, explanation: 'As the sun was sinking, Hans walked along the path and found a tiny leak trickling water.' }
        ]
      },
      {
        id: 'h-while-2',
        type: 'sequencing',
        skill: 'SEQUENCING',
        title: 'Chronology: The Path of the Hero',
        instruction: 'Arrange these critical events in chronological order (from first to last) as they happened in the tale.',
        points: 4,
        items: [
          { id: 'seq1', text: 'Hans walks along the dyke path to deliver fresh bread to his blind friend.', correctOrder: 0 },
          { id: 'seq2', text: 'Hearingtrickling water, Hans discovers a tiny hole leaking cold sea water.', correctOrder: 1 },
          { id: 'seq3', text: 'Hans pushes his forefinger into the leak to block the water as night falls.', correctOrder: 2 },
          { id: 'seq4', text: 'He spends a long, freezing night alone, refusing to let the sea flood Haarlem.', correctOrder: 3 },
          { id: 'seq5', text: 'In the morning, a clergyman hears Hans and calls the townspeople to repair the dyke.', correctOrder: 4 }
        ]
      },
      {
        id: 'h-while-3',
        type: 'detail-mc',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Detail Retreival: Hans\'s Choice',
        question: 'Why did Hans decide to plug the dyke hole with his finger instead of running home to get his father immediately?',
        instruction: 'Choose the best answer based on what you have read.',
        points: 4,
        options: [
          { value: 'a', label: 'Hans wanted to show off his strength and become famous in the morning.', isCorrect: false, feedback: 'Incorrect. Hans had no selfish motives; he was terrified but knew the danger.' },
          { value: 'b', label: 'He knew that if he walked away, the leak would quickly expand into a great gap and flood the town before he could return.', isCorrect: true, feedback: 'Excellent! He realized that running for help would take too long and the dyke would collapse in his absence.' },
          { value: 'c', label: 'His path home was blocked by a large sheep and he was too scared to pass it.', isCorrect: false, feedback: 'Incorrect. There was no sheep blocking his way; the street was empty but he stayed because of the water danger.' },
          { value: 'd', label: 'The old blind man commanded him to stand guard near the water.', isCorrect: false, feedback: 'Incorrect. The old blind man was back at his cottage and did not know about the leak.' }
        ]
      },
      {
        id: 'h-while-4',
        type: 'vocab-context',
        skill: 'VOCABULARY',
        title: 'Vocabulary in Context: Identify the Word',
        question: 'Which word from the text means "lacking color in the face, whitish, due to cold or fear"?',
        instruction: 'Click on the correct vocabulary word from the selection below.',
        points: 4,
        passage: 'Hans became pale with fear. He realized the danger immediately.',
        correctWord: 'pale',
        options: ['pale', 'fear', 'danger', 'immediately']
      },
      {
        id: 'h-while-5',
        type: 'fill-in-blank',
        skill: 'VOCABULARY',
        title: 'Vocabulary Check: The Cold Breach',
        instruction: 'Select the correct vocabulary words from the dropdown menus to complete the summary of Hans\'s night.',
        points: 4,
        textWithBlanks: 'In the cold midnight hours, the freezing sea water continued to [blank1] against the stones. Hans pushed his [blank2] firmly into the hole. His fingers began to [blank3] as his cheeks turned [blank4].',
        blanks: [
          { key: 'blank1', correctAnswer: 'bubble', options: ['bubble', 'whisper', 'dry', 'disappear'] },
          { key: 'blank2', correctAnswer: 'forefinger', options: ['forefinger', 'shoulder', 'shoe', 'bread'] },
          { key: 'blank3', correctAnswer: 'feel numb', options: ['feel numb', 'burn', 'laugh', 'grow warm'] },
          { key: 'blank4', correctAnswer: 'pale', options: ['pale', 'red', 'golden', 'happy'] }
        ]
      },
      {
        id: 'h-while-6',
        type: 'grammar-mc',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Grammar in Action: Irregular Verbs',
        question: 'Identify the correct Past Simple forms of the irregular verbs used in Section 1: "choose" and "become".',
        instruction: 'Choose the correct pair of past tense forms.',
        points: 4,
        options: [
          { value: 'a', label: 'choosed, becomed', isCorrect: false, feedback: 'Incorrect. These are irregular verbs, so they do not take "-ed".' },
          { value: 'b', label: 'chose, became', isCorrect: true, feedback: 'Splendid! "chose" is the past tense of "choose", and "became" is the past tense of "become".' },
          { value: 'c', label: 'chosen, become', isCorrect: false, feedback: 'Incorrect. "chosen" is the past participle, and "become" is the base form.' },
          { value: 'd', label: 'chooses, becomes', isCorrect: false, feedback: 'Incorrect. These are present tense forms.' }
        ]
      }
    ],
    postReadingTasks: [
      {
        id: 'h-post-1',
        type: 'inference-mc',
        skill: 'INFERENCE',
        title: 'Deep Inference: True Motivation',
        question: 'What does Hans’s secret prayer and soft whisper in Section 3 reveal about his character?',
        instruction: 'Pick the option that best captures his psychological and moral state.',
        points: 4,
        options: [
          { value: 'a', label: 'He was extremely angry at his parents for not looking for him.', isCorrect: false, feedback: 'Incorrect. He felt no anger, only love, wanting to protect them as they slept.' },
          { value: 'b', label: 'He is driven by deep social responsibility and love for his community, choosing their safety over his own comfort.', isCorrect: true, feedback: 'Superb! Despite the physical suffering (numbness, pale face), his thoughts are centered on saving the innocent townspeople.' },
          { value: 'c', label: 'He wanted to escape his schoolwork by staying outside all night.', isCorrect: false, feedback: 'Incorrect. He loved reading to his friend and was not trying to skip school.' }
        ]
      },
      {
        id: 'h-post-2',
        type: 'moral-mc',
        skill: 'INFERENCE',
        title: 'Moral Focus: The Scope of Heroism',
        question: 'The story suggests that a "hero" is someone who:',
        instruction: 'Choose the answer that represents the ethical lesson of this Dutch tale.',
        points: 4,
        options: [
          { value: 'a', label: 'Does grand, loud deeds to gain silver and gold axes.', isCorrect: false, feedback: 'Incorrect. A hero does not look for wealth (like the axes in Tale 3).' },
          { value: 'b', label: 'Is old, physically strong, and commands massive armies in battle.', isCorrect: false, feedback: 'Incorrect. Hans was just an 8-year-old child who saved Haarlem through simple, quiet endurance.' },
          { value: 'c', label: 'Acts selflessly, takes responsibility in times of crisis, and endures hardship to protect others.', isCorrect: true, feedback: 'Perfect! True heroism is presented as selflessness, immediate responsibility, and loving endurance.' }
        ]
      },
      {
        id: 'h-post-3',
        type: 'mind-map',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Mind Map: Hans\'s Character Traits',
        instruction: 'Select exactly 3 traits that Hans exhibits in "The Little Hero of Haarlem". Select correctly based on our reading.',
        points: 4,
        characterName: 'Hans',
        traits: [
          { trait: 'Selfless (Brave & Caring)', isCorrect: true, description: 'He sacrificed his comfort and safety to save Haarlem.' },
          { trait: 'Greedy & Selfish', isCorrect: false, description: 'He never expected coins or praise for his action.' },
          { trait: 'Responsible / Mature', isCorrect: true, description: 'He understood the fatal consequences of the leak immediately.' },
          { trait: 'Lazy & Inattentive', isCorrect: false, description: 'He was looking carefully at the path and heard the trickle.' },
          { trait: 'Persistent / Resolute', isCorrect: true, description: 'He stayed through the freezing night in spite of pain and numbness.' },
          { trait: 'Boastful / Arrogant', isCorrect: false, description: 'He was shivering and crying, whispering humbly.' }
        ],
        requiredCount: 3
      },
      {
        id: 'h-post-4',
        type: 'retelling',
        skill: 'SEQUENCING',
        title: 'Story Retelling: Summary Arrangement',
        instruction: 'Reorder these 5 summary sentences to formulate a coherent paragraphs-long retelling of the legend.',
        points: 4,
        items: [
          { id: 'ret1', text: 'Hans lives in Haarlem, a city guarded by massive sea dykes.', correctOrder: 0 },
          { id: 'ret2', text: 'On his way back from a friendly visit, he notices a tiny leak trickling water.', correctOrder: 1 },
          { id: 'ret3', text: 'Knowing the danger, Hans plugs the hole with his forefinger to stop the water.', correctOrder: 2 },
          { id: 'ret4', text: 'He endures a freezing, painful night in complete solitude.', correctOrder: 3 },
          { id: 'ret5', text: 'The townspeople rescue him in the morning, celebrating him as a savior.', correctOrder: 4 }
        ]
      },
      {
        id: 'h-post-5',
        type: 'creative-text',
        skill: 'INFERENCE',
        title: 'Creative Extension: My Letter to Hans',
        instruction: 'If you could send a short message to Hans on the morning he was found, what would you write? Aim for at least 15 words in your English response.',
        points: 4,
        placeholder: 'Dear Hans, you are so brave because...',
        minWords: 10
      }
    ]
  },
  {
    id: 'magic-porridge-pot',
    title: 'The Story of the Magic Porridge Pot',
    theme: 'GOOD DEEDS',
    icon: '🪄',
    teaser: 'A sweet magic pot feeds a poor girl and her mother. But things go wild when her mother forgets the magic stop words!',
    difficulty: 'Easy',
    durationMinutes: 20,
    grammarFocus: 'Comparatives & Superlatives (big→bigger→biggest, tiny→tinier→tiniest); Prepositions; Irregular plurals (men, teeth, children, mice)',
    keyVocabulary: ['porridge', 'sorrow', 'bowl', 'pot', 'overflow', 'stove', 'hunger', 'poverty', 'spill', 'greedy'],
    vocabularyList: [
      { word: 'porridge', definition: 'A soft, thick food made by boiling oats or other grains in milk or water', example: 'The little pot cooked hot, sweet oatmeal porridge.', kazakh: 'ботқа' },
      { word: 'sorrow', definition: 'A feeling of deep distress or sadness', example: 'They had lived in sorrow and hunger for many long months.', kazakh: 'қайғы (мұң)' },
      { word: 'bowl', definition: 'A round, deep dish used for holding liquid or soft food', example: 'Mother scooped the rich porridge into a wooden bowl.', kazakh: 'тостаған (кесе)' },
      { word: 'pot', definition: 'A deep, rounded container used for cooking food on a stove', example: 'The old woman presented her with an iron boiling pot.', kazakh: 'кәстрөл (қазан)' },
      { word: 'overflow', definition: 'To flood or spill over the edge of a container because it is too full', example: 'The boiling porridge began to overflow the kitchen.', kazakh: 'тасып төгілу' },
      { word: 'stove', definition: 'An apparatus or appliance in which fuel is burned to heat or cook food', example: 'The magical pot sat cooking on the burning wood stove.', kazakh: 'пеш (плита)' },
      { word: 'hunger', definition: 'A strong desire or need for food; the physical state of needing to eat', example: 'Their hunger was finally satisfied by the magic pot.', kazakh: 'аштық' },
      { word: 'poverty', definition: 'The state of being extremely poor, with little money or possessions', example: 'The little family rose out of poverty when they received the pot.', kazakh: 'кедейлік' },
      { word: 'spill', definition: 'To flow, run, or fall over the edge of a container accidentally', example: 'The sticky porridge started to spill down the narrow street.', kazakh: 'төгілу (шашылу)' },
      { word: 'greedy', definition: 'Having an excessive or selfish desire for more food, money, or power', example: 'A greedy neighbor wanted to steal the pot for herself.', kazakh: 'ашқарақ (тойымсыз)' }
    ],
    sections: [
      {
        id: 'pot-1',
        title: 'Section 1: The Bread of Kindness',
        content: `Once upon a time, in a small, cozy village surrounded by thick forests, there lived a good, kind girl named Greta. She lived with her mother in a tiny, weathered cottage. They were so poor that they lived in deep poverty. Often, they went to sleep with nothing but hunger and sorrow in their hearts. One freezing winter morning, there was absolutely no food left in the cottage, not even a crust of stale bread. Greta went into the deep, snowy forest, hoping to find some wild berries or frozen nuts. She was shivering with cold and crying from hunger. Suddenly, behind a large oak tree, she met an old woman with kind eyes and a warm silver cloak. Seeing Greta's tears, the old woman asked gently, "Why are you weeping, little child?" Greta looked down at her small, cold feet and answered, "My mother and I are starving of hunger, and we have no porridge to eat."`,
        vocabularyHighlights: [
          { word: 'poverty', definition: 'The state of being extremely poor', kazakh: 'кедейлік' },
          { word: 'hunger', definition: 'A strong need or desire for food', kazakh: 'аштық' },
          { word: 'sorrow', definition: 'A feeling of deep distress or sadness', kazakh: 'қайғы' }
        ]
      },
      {
        id: 'pot-2',
        title: 'Section 2: Cook, Little Pot, Cook!',
        content: `The old woman smiled warmly and pulled a tiny, dark iron pot from under her silver cloak. "Dry your eyes, sweet girl," the old woman said, "for you have a kind heart. I give you this magic pot. Whenever you say the words, 'Cook, little pot, cook!' it will fill itself with the sweetest, warmest porridge you have ever tasted. And when you say, 'Stop, little pot, stop!' it will instantly cease cooking." Greta was astonished. She held the tiny pot close, thanked the mysterious woman, and ran home as fast as her cold feet could carry her. She placed the pot on the kitchen table and said, "Cook, little pot, cook!" At once, the sweet steam rose, and the pot filled up with delicious, sweet porridge. Greta and her mother ate until they were full, filling their bowls to the brim. Greta said, "Stop, little pot, stop!" and the cooking ceased. Their poverty and starving days were over.`,
        vocabularyHighlights: [
          { word: 'pot', definition: 'A deep container used for cooking', kazakh: 'қазан' },
          { word: 'porridge', definition: 'Soft thick food made by boiling grains', kazakh: 'ботқа' },
          { word: 'bowl', definition: 'A round deep dish for food', kazakh: 'тостаған' }
        ]
      },
      {
        id: 'pot-3',
        title: 'Section 3: The Forgetful Mother',
        content: `One sunny afternoon, Greta went for a stroll in the meadow to play with the other children. While she was gone, her mother began to feel hungry again. She took the magic pot from behind the cupboard, placed it on the stove, and said, "Cook, little pot, cook!" The pot began to bubble and cook. The mother filled a large wooden bowl and ate happily, enjoying the hot, sweet porridge. But when she was completely full, she wanted the pot to stop. Unfortunately, she could not remember the exact words! Instead of saying "Stop, little pot, stop!", she shouted, "That is enough! No more! Stop cooking, pot! Please stop!" But the magic pot did not understand these commands. It kept cooking and cooking. Soon, the porridge began to overflow the pot. It spilled onto the stove, and poured onto the wooden floor.`,
        vocabularyHighlights: [
          { word: 'overflow', definition: 'To flood or spill over the edge of a container', kazakh: 'тасып төгілу' },
          { word: 'spill', definition: 'To run or fall over the edge accidentally', kazakh: 'төгілу' },
          { word: 'stove', definition: 'An apparatus in which fuel is heated for cooking', kazakh: 'пеш' }
        ]
      },
      {
        id: 'pot-4',
        title: 'Section 4: A Village of Sweet Porridge',
        content: `The mother panicked. She tried to throw a bucket of cold water on the pot, but the porridge continued to rise. The sweet porridge flowed out of the cottage door, spilled into the narrow streets, and began to stream like a thick river of lava. It flooded the next-door neighbors’ houses. The villagers ran out into the street. Greedy dogs licked the ground, while cats climbed onto high roofs. Men, children, and even little mice ran behind the church to escape the sweet wave. The entire village was filled with porridge, and it seemed as if the whole world was becoming a giant porridge bowl! Nobody could stop it. At last, when there was only one small house left untouched, Greta returned. Seeing the porridge river, she ran to her house and cried, "Stop, little pot, stop!" At once, the pot ceased. The flood stopped, but for weeks, anyone who wanted to come back into the village had to eat their way through the sweet, sticky streets!`,
        vocabularyHighlights: [
          { word: 'spill', definition: 'To flow over the edge', kazakh: 'төгілу' },
          { word: 'pot', definition: 'Deep cooking vessel', kazakh: 'қазан' }
        ]
      }
    ],
    preReadingTasks: [
      {
        id: 'p-pre-1',
        type: 'prediction',
        skill: 'MAIN_IDEA',
        title: 'Visual Clues: The Mysterious Pot',
        instruction: 'Look at the magical title and icon 🪄. What do you think is special about a "Magic Porridge Pot"? Why would a pot be magic?',
        points: 5,
        placeholder: 'I think the pot is magical because it can...'
      },
      {
        id: 'p-pre-2',
        type: 'matching',
        skill: 'VOCABULARY',
        title: 'Vocabulary Preview: Kitchen Wonders',
        instruction: 'Match the story vocabulary words to their correct meaning to prepare your mind for reading.',
        points: 5,
        pairs: [
          { id: 'pp1', word: 'porridge', definition: 'A soft, thick hot oatmeal food made by boiling grains in milk or water' },
          { id: 'pp2', word: 'sorrow', definition: 'A feeling of deep sadness, sadness of the heart' },
          { id: 'pp3', word: 'overflow', definition: 'To spill or flow over the edge of a container because it is too full' },
          { id: 'pp4', word: 'stove', definition: 'An appliance used for heating or cooking food in the kitchen' },
          { id: 'pp5', word: 'greedy', definition: 'An excessive desire to have more than you need, like food or gold' }
        ]
      },
      {
        id: 'p-pre-3',
        type: 'text-warmup',
        skill: 'INFERENCE',
        title: 'Warm-up: Helping Hearts',
        instruction: 'Think about kindness. Answer in 1 or 2 simple sentences.',
        points: 5,
        question: 'How do you help your parents at home when they are busy or tired? What is a good deed you did recently?',
        placeholder: 'I recently helped by...'
      },
      {
        id: 'p-pre-4',
        type: 'prediction-slider',
        skill: 'MAIN_IDEA',
        title: 'Prediction: The Magic Rule',
        instruction: 'What rule or secret word do you predict Greta and her mother must remember to control the magic pot?',
        points: 5,
        options: [
          { value: 'secret-phrase', label: '1. Magic Phrase', description: 'They must speak a very precise, matching phrase to make the pot start and stop cooking.' },
          { value: 'coin-payment', label: '2. Golden Coin', description: 'They must insert a golden coin into the bottom of the pot every time they want to eat.' },
          { value: 'silent-dance', label: '3. A Silent Dance', description: 'They must perform a quick silent circle around the stove to cook without burning.' }
        ]
      }
    ],
    whileReadingTasks: [
      {
        id: 'p-while-1',
        type: 'true-false',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Comprehension Check: True or False?',
        instruction: 'Select True or False for each statement based on Sections 1 & 2 of the story.',
        points: 4,
        statements: [
          { id: 'ptf1', statement: 'Greta and her mother lived in a massive, rich king\'s palace.', isTrue: false, explanation: 'Greta and her mother lived in a tiny, weathered cottage in deep poverty.' },
          { id: 'ptf2', statement: 'Greta walked into the snowy forest to search for berries or nuts.', isTrue: true, explanation: 'Yes, she went to the freezing forest looking for frozen nuts or berries because they had no food.' },
          { id: 'ptf3', statement: 'The magic old woman gave her a pot that could cook gold coins.', isTrue: false, explanation: 'The pot cooked delicious, sweet porridge, not gold coins.' },
          { id: 'ptf4', statement: 'The command "Stop, little pot, stop!" makes the pot cease cooking immediately.', isTrue: true, explanation: 'Yes, that is the exact magic formula of closure taught by the old woman.' }
        ]
      },
      {
        id: 'p-while-2',
        type: 'sequencing',
        skill: 'SEQUENCING',
        title: 'Chronology: Porridge Flood!',
        instruction: 'Rearrange the events in their correct narrative sequence as they unfolded in the village.',
        points: 4,
        items: [
          { id: 'pseq1', text: 'Greta goes to play in the meadow while her mother stays home and gets hungry.', correctOrder: 0 },
          { id: 'pseq2', text: 'Mother says "Cook, little pot, cook!" and eats a hot bowl of sweet porridge.', correctOrder: 1 },
          { id: 'pseq3', text: 'Mother forgets the magic ending words and screams "Stop cooking, pot!" which does not work.', correctOrder: 2 },
          { id: 'pseq4', text: 'The porridge overflows, spilling onto the stove, filling the streets and houses.', correctOrder: 3 },
          { id: 'pseq5', text: 'Greta returns, shouts "Stop, little pot, stop!" and saves the final house from the flood.', correctOrder: 4 }
        ]
      },
      {
        id: 'p-while-3',
        type: 'detail-mc',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Detail Check: Starving Village',
        question: 'Who/what escaped the porridge river by climbing onto the high roofs or running behind the church?',
        instruction: 'Pick the correct description of the escaping animals and villagers.',
        points: 4,
        options: [
          { value: 'a', label: 'Ducks and geese flew away to a warmer country.', isCorrect: false, feedback: 'Incorrect. The text does not mention ducks or geese flying away.' },
          { value: 'b', label: 'Dogs licked the ground, cats climbed onto roofs, and men, children, and little mice ran behind the church.', isCorrect: true, feedback: 'Grand! The text lists dogs, cats, men, children, and little mice escaping the porridge.' },
          { value: 'c', label: 'A brave prince rode his white horse to drink up the porridge.', isCorrect: false, feedback: 'Incorrect. No prince appeared; the villagers had to handle it themselves.' },
          { value: 'd', label: 'The old blind man from Haarlem arrived to shovel the porridge.', isCorrect: false, feedback: 'Incorrect. That character is from Tale 1!' }
        ]
      },
      {
        id: 'p-while-4',
        type: 'vocab-context',
        skill: 'VOCABULARY',
        title: 'Vocabulary in Context: Pouring Liquid',
        question: 'Which word in the text means "to flow or run over the edge of a container because it is too full"?',
        instruction: 'Click on the target word below.',
        points: 4,
        passage: 'Soon, the porridge began to overflow the pot. It spilled onto the stove...',
        correctWord: 'overflow',
        options: ['porridge', 'overflow', 'pot', 'spilled']
      },
      {
        id: 'p-while-5',
        type: 'fill-in-blank',
        skill: 'VOCABULARY',
        title: 'Interactive Vocabulary: Pot and Bowl',
        instruction: 'Complete the blanks with the correct words about Greta\'s magic utensil.',
        points: 4,
        textWithBlanks: 'The little girl received a magic [blank1] that could cook delicious hot [blank2]. She filled a deep wooden [blank3] to eat. But the mother took it and caused the porridge to [blank4] down the kitchen stove.',
        blanks: [
          { key: 'blank1', correctAnswer: 'pot', options: ['pot', 'bucket', 'spoon', 'house'] },
          { key: 'blank2', correctAnswer: 'porridge', options: ['porridge', 'tea', 'bread', 'berries'] },
          { key: 'blank3', correctAnswer: 'bowl', options: ['bowl', 'stove', 'silver hat', 'dyke'] },
          { key: 'blank4', correctAnswer: 'overflow', options: ['overflow', 'freeze', 'disappear', 'whisper'] }
        ]
      },
      {
        id: 'p-while-6',
        type: 'grammar-mc',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Grammar Focus: Plural Nouns & Comparatives',
        question: 'Section 4 mentions "men", "children", and "mice". What are their singular forms?',
        instruction: 'Identify the correct singular nouns.',
        points: 4,
        options: [
          { value: 'a', label: 'mans, childs, mouses', isCorrect: false, feedback: 'Incorrect. These are irregular plurals, their singulars do not end like this.' },
          { value: 'b', label: 'man, child, mouse', isCorrect: true, feedback: 'Splendid! Man (singular) -> Men (plural); Child -> Children; Mouse -> Mice. These are fundamental irregular plurals.' },
          { value: 'c', label: 'male, kid, rat', isCorrect: false, feedback: 'Incorrect. While similar in meaning, they are not the singular counterparts of the words in the story.' },
          { value: 'd', label: 'man, children, mice', isCorrect: false, feedback: 'Incorrect. This option mixed singular and plural forms.' }
        ]
      }
    ],
    postReadingTasks: [
      {
        id: 'p-post-1',
        type: 'inference-mc',
        skill: 'INFERENCE',
        title: 'Inference: Why the Old Woman Helped',
        question: 'Why did the mysterious old woman decide to gift Greta the precious magic porridge pot?',
        instruction: 'Examine her motives based on Section 1.',
        points: 4,
        options: [
          { value: 'a', label: 'She wanted to sell the pot but Greta was the only person in the forest.', isCorrect: false, feedback: 'Incorrect. The old woman gave it as a free gift, not a sale.' },
          { value: 'b', label: 'Greta was a good, kind girl crying in poverty, and the old woman valued her kind heart.', isCorrect: true, feedback: 'Wonderful! The old woman says "for you have a kind heart. I give you this magic pot," praising her goodness.' },
          { value: 'c', label: 'The old woman wanted to play a trick on the village and flood it.', isCorrect: false, feedback: 'Incorrect. The old woman had kind eyes and wanted to help; the flood was the mother\'s mistake, not the old woman\'s plan.' }
        ]
      },
      {
        id: 'p-post-2',
        type: 'moral-mc',
        skill: 'INFERENCE',
        title: 'Moral Discussion: Instruction & Rules',
        question: 'What is the main pedagogical moral of "The Magic Porridge Pot" story?',
        instruction: 'Choose the most complete ethical lesson.',
        points: 4,
        options: [
          { value: 'a', label: 'It is better not to eat porridge at all because it is dangerous.', isCorrect: false, feedback: 'Incorrect. Porridge was a blessing that ended their poverty.' },
          { value: 'b', label: 'Cooking is too difficult for parents and should only be done by children.', isCorrect: false, feedback: 'Incorrect. Anyone can cook, but they must know the rules.' },
          { value: 'c', label: 'When you use powerful or magical tools, you must carefully listen to instructions and learn the proper rules (words) of control.', isCorrect: true, feedback: 'Excellent! The mother used a powerful tool without knowing the controls (the ending words), leading to a disaster. This is a great lesson on following instructions.' }
        ]
      },
      {
        id: 'p-post-3',
        type: 'mind-map',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Mind Map: Character Traits of Greta',
        instruction: 'Select exactly 3 positive character traits shown by Greta in this wonderful tale.',
        points: 4,
        characterName: 'Greta',
        traits: [
          { trait: 'Kind-hearted & Loving', isCorrect: true, description: 'She wept for her starving mother and thanked the old woman warmly.' },
          { trait: 'Greedy & Demanding', isCorrect: false, description: 'She was humble and grateful, never asking for more than food.' },
          { trait: 'Polite & Grateful', isCorrect: true, description: 'She thanked the mystical woman politely and held her connection.' },
          { trait: 'Forgetful & Reckless', isCorrect: false, description: 'She remembered the starting AND ending words perfectly.' },
          { trait: 'Responsible and Alert', isCorrect: true, description: 'She ran home immediately to help and stopped the flood with her voice.' },
          { trait: 'Scared and Hesitant', isCorrect: false, description: 'She bravely walked in the snowy forest looking for food.' }
        ],
        requiredCount: 3
      },
      {
        id: 'p-post-4',
        type: 'retelling',
        skill: 'SEQUENCING',
        title: 'Story Retelling: The Porridge Adventure',
        instruction: 'Sort these summary points to recreate the sweet narrative arc of Greta\'s pot.',
        points: 4,
        items: [
          { id: 'pret1', text: 'Greta and her mother live in cold poverty with nothing to eat.', correctOrder: 0 },
          { id: 'pret2', text: 'A kind old woman in the forest gifts Greta a magic porridge pot.', correctOrder: 1 },
          { id: 'pret3', text: 'The pot provides sweet hot porridge using magic phrases of command.', correctOrder: 2 },
          { id: 'pret4', text: 'The mother forgets the stop phrase, causing a giant sweet porridge flood.', correctOrder: 3 },
          { id: 'pret5', text: 'Greta returns, shouts the stop words, and saves the village from drowning.', correctOrder: 4 }
        ]
      },
      {
        id: 'p-post-5',
        type: 'creative-text',
        skill: 'INFERENCE',
        title: 'Creative Project: The Mother\'s Apology',
        instruction: 'Write 2 simple English sentences: What does the mother say to Greta when Greta finally stops the sweet porridge flood?',
        points: 4,
        placeholder: '"I am so sorry, Greta! Next time I will surely remember to...',
        minWords: 10
      }
    ]
  },
  {
    id: 'honest-woodcutter',
    title: 'The Honest Woodcutter (in Modern Times)',
    theme: 'HONESTY',
    icon: '🪓',
    teaser: 'A modern take on the traditional tale of a poor woodcutter who drops his axe, facing a testing goddess.',
    difficulty: 'Hard',
    durationMinutes: 25,
    grammarFocus: 'Adjectives (honest, greedy, golden, silver, iron); Moral analysis; Comprehension checking',
    keyVocabulary: ['sorrow', 'honest', 'reward', 'deserve', 'greedy', 'goddess', 'silver', 'iron', 'axe'],
    vocabularyList: [
      { word: 'sorrow', definition: 'Deep sadness or distress caused by loss or misfortune', example: 'The poor woodcutter wept in sorrow when his axe fell into the river.', kazakh: 'қайғы' },
      { word: 'honest', definition: 'Truthful, sincere, free of deceit and lies', example: 'An honest person always speaks the truth, even if they lose money.', kazakh: 'адал' },
      { word: 'reward', definition: 'Something given in return for good behavior, outstanding service, or honesty', example: 'The goddess gave him all three axes as a reward.', kazakh: 'сыйлық (марапат)' },
      { word: 'deserve', definition: 'To be worthy of something because of your actions or character qualities', example: 'You deserve a great prize for telling the truth.', kazakh: 'лайықты болу' },
      { word: 'greedy', definition: 'Having or showing an intense and selfish desire for wealth, money, or food', example: 'The greedy neighbor wanted to claim the golden axe with a lie.', kazakh: 'тойымсыз' },
      { word: 'goddess', definition: 'A female deity or magical spirit with supernatural powers', example: 'The beautiful river goddess emerged from the shining blue water.', kazakh: 'богиня (әйел Тәңірі / су перісі)' },
      { word: 'silver', definition: 'A precious shiny white metallic element used for coins, jewelry, and high-quality axes', example: 'The silver axe shone brightly under the sun.', kazakh: 'күміс' },
      { word: 'iron', definition: 'A strong, heavy dark-metal element used to make useful tools like ordinary woodcutter axes', example: 'His simple iron axe slip-and-fell into the deep canal.', kazakh: 'темір' },
      { word: 'axe', definition: 'A tool with a heavy metal blade on a wooden handle, used for chopping wood', example: 'A woodcutter cannot work or earn a living without his trusty axe.', kazakh: 'балта' }
    ],
    sections: [
      {
        id: 'wood-1',
        title: 'Section 1: The Lost Blade',
        content: `Once upon a time, in a high mountainous valley in modern Almaty, near a crystal-clear, fast-running river, there lived a humble woodcutter named Arman. Arman spent his days chopping dead trees to Sell firewood, earning just enough coins to buy food for his family. He was extremely poor, but everyone in the valley respected him because he was honest and kind. Arman had one single tool: an old, heavy iron axe with a cracked wooden handle. One bright morning, as he was trimming a thick branch hanging over the deep river, his sweaty hand slipped. SPLASH! The heavy iron axe flew from his grip and sank deep into the swirling blue water. Arman sat on the rocky bank and began to weep. "Oh no! My axe!" he cried in deep sorrow. "I have no money to buy another, and my family will starve without firewood coins!"`,
        vocabularyHighlights: [
          { word: 'iron', definition: 'A strong grey metal used to make sturdy ordinary tools', kazakh: 'темір' },
          { word: 'axe', definition: 'A heavy chopping tool with a blade', kazakh: 'балта' },
          { word: 'sorrow', definition: 'A feeling of deep distress or sadness', kazakh: 'қайғы' }
        ]
      },
      {
        id: 'wood-2',
        title: 'Section 2: The Luminous Gift',
        content: `Suddenly, the water bubbled and began to glow with an emerald light. Out of the deep river rose a beautiful, glowing river goddess. She wore a dress made of liquid light, and her hair was like flowing water. "Why are you weeping, honest woodcutter?" she asked in a voice like chimes. Arman dried his tears and explained, "My iron axe fell into your deep river. It is my only tool!" The goddess nodded, smiled, and dived deep. When she returned, she held a dazzling golden axe that caught the morning light. "Is this golden axe yours, Arman?" she asked. Arman looked at the glorious blade, shook his head, and replied, "No, beautiful goddess. That is a golden axe, and it does not belong to me."`,
        vocabularyHighlights: [
          { word: 'goddess', definition: 'A female deity or water spirit', kazakh: 'су перісі' },
          { word: 'honest', definition: 'Truthful, telling the truth', kazakh: 'адал' }
        ]
      },
      {
        id: 'wood-3',
        title: 'Section 3: The Ultimate Truth',
        content: `The goddess smiled even wider and dived back into the rushing river. In a few seconds, she emerged carrying a gorgeous silver axe, polished like a mirror. "Is this silver axe the tool you dropped?" she asked gently. Once again, Arman remained completely honest. "No," he smiled, "that is a silver axe. Mine is just a heavy, rusty iron axe." The goddess dived a third time. She brought up Arman\'s own iron axe with the cracked wooden handle. "Yes! That is indeed my axe! Thank you!" Arman rejoiced, taking his old tool. The goddess was deeply impressed. "You are truly honest, Arman," she said. "You chose truth over luxury. You deserve a reward!" She handed him his iron axe, along with both the golden and silver axes as prizes of honor. Arman returned home rich and safe.`,
        vocabularyHighlights: [
          { word: 'silver', definition: 'A shiny white precious metal', kazakh: 'күміс' },
          { word: 'reward', definition: 'A prize given for good behavior or truth', kazakh: 'сыйлық' },
          { word: 'deserve', definition: 'To be worthy of receiving something', kazakh: 'лайықты болу' }
        ]
      },
      {
        id: 'wood-4',
        title: 'Section 4: The Greed and the Void',
        content: `News of Arman’s fortune spread through the village. A greedy neighbor named Murat heard of the golden and silver axes and became extremely jealous. "I want those rich axes too!" Murat thought. He grabbed a rusty iron axe, ran to the exact same rocky bank, and threw his axe into the river on purpose. He sat down and shouted, weeping loudly, "Axe! Oh, my beautiful axe is lost!" The river goddess emerged from the water. She dived and showed Murat a gleaming golden axe. Murat’s eyes filled with greed. "Yes, yes! That is my golden axe! I dropped it!" he lied, reaching out. The goddess’s face turned cold. "You are dishonest and greedy," she said. "You try to deceive me." She dropped the golden axe back into the deep water and vanished. Murat was left with nothing—losing both the golden axe and his own iron axe!`,
        vocabularyHighlights: [
          { word: 'greedy', definition: 'Extremely selfish, desiring more than needed', kazakh: 'тойымсыз' },
          { word: 'honest', definition: 'Sincere and truthful', kazakh: 'адал' }
        ]
      }
    ],
    preReadingTasks: [
      {
        id: 'w-pre-1',
        type: 'prediction',
        skill: 'MAIN_IDEA',
        title: 'Prediction: The Dilemma of Gold',
        instruction: 'Under the theme "Honesty", think about what options a poor logger has when offered a golden axe that is not theirs.',
        points: 5,
        placeholder: 'I think Arman will choose to tell the truth because...'
      },
      {
        id: 'w-pre-2',
        type: 'matching',
        skill: 'VOCABULARY',
        title: 'Vocabulary: Precious Metals & Moral Traits',
        instruction: 'Match these essential terms before reading about Arman and Murat.',
        points: 5,
        pairs: [
          { id: 'wp1', word: 'honest', definition: 'Truthful, not telling lies or stealing' },
          { id: 'wp2', word: 'greedy', definition: 'Selfishly wanting more money, gold, or items than one deserves' },
          { id: 'wp3', word: 'reward', definition: 'A prize or token of appreciation granted for good deeds' },
          { id: 'wp4', word: 'goddess', definition: 'A female water-spirit or supernatural deity' },
          { id: 'wp5', word: 'deserve', definition: 'To have earned or be entirely worthy of a prize based on behavior' }
        ]
      },
      {
        id: 'w-pre-3',
        type: 'text-warmup',
        skill: 'INFERENCE',
        title: 'Warm-up: The Value of Truth',
        instruction: 'Write 1 or 2 simple sentences in English answering the dilemma.',
        points: 5,
        question: 'Is it always easy to tell the truth? Why do you think honesty is important to have in physical or school life?',
        placeholder: 'Honesty is important because...'
      },
      {
        id: 'w-pre-4',
        type: 'prediction-slider',
        skill: 'MAIN_IDEA',
        title: 'Consequence Slider: What Awaits Lies?',
        instruction: 'Move the slider to predict what will happen to the dishonest neighbor Murat at the end.',
        points: 5,
        options: [
          { value: 'nothing', label: '1. No Reward', description: 'Goddess ignores his cry and he simply has to swim to retrieve his common iron axe.' },
          { value: 'punishment', label: '2. Complete Loss', description: 'Goddess punishes him by locking both axes deep in the river, leaving him tool-less.' },
          { value: 'jail', label: '3. Legal Police', description: 'The local rangers catch him throwing iron tools into the clear water and fine him.' }
        ]
      }
    ],
    whileReadingTasks: [
      {
        id: 'w-while-1',
        type: 'true-false',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Comprehension Checking: True/False',
        instruction: 'Read Sections 1 and 2 carefully and check the accuracy of these statements.',
        points: 4,
        statements: [
          { id: 'wtf1', statement: 'Arman was a wealthy merchant who owned three lumbermills in Almaty.', isTrue: false, explanation: 'Arman was a very poor woodcutter who owned just one iron axe.' },
          { id: 'wtf2', statement: 'Arman\'s iron axe slipped from his hand and fell into the swirling river.', isTrue: true, explanation: 'Yes, his sweaty hand slipped and the heavy axe flew and sank in the water.' },
          { id: 'wtf3', statement: 'The river goddess emerged from the water holding a laser cutter.', isTrue: false, explanation: 'She emerged holding a dazzling golden axe.' },
          { id: 'wtf4', statement: 'Arman immediately accepted the golden axe and said it belonged to him.', isTrue: false, explanation: 'Arman was honest and said the golden axe was not his.' }
        ]
      },
      {
        id: 'w-while-2',
        type: 'sequencing',
        skill: 'SEQUENCING',
        title: 'Chronology: The Honest vs Greedy Path',
        instruction: 'Arrange the plot milestones in the correct chronological order.',
        points: 4,
        items: [
          { id: 'wseq1', text: 'Arman accidentally drops his iron axe and weeps on the rocky bank.', correctOrder: 0 },
          { id: 'wseq2', text: 'The river goddess offers Arman a golden axe and a silver axe, which he honestly refuses.', correctOrder: 1 },
          { id: 'wseq3', text: 'Arman claims his own iron axe and is rewarded with all three axes by the goddess.', correctOrder: 2 },
          { id: 'wseq4', text: 'Murat throws his axis intentionally and falsely claims the golden axe is his.', correctOrder: 3 },
          { id: 'wseq5', text: 'The goddess rejects Murat\'s lies and vanishes, leaving him completely axe-less.', correctOrder: 4 }
        ]
      },
      {
        id: 'w-while-3',
        type: 'detail-mc',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Detail Retreival: Arman\'s Metal',
        question: 'What axe did Arman drop, and what did the handle of his real tool look like?',
        instruction: 'Reflect on the descriptions in Section 1.',
        points: 4,
        options: [
          { value: 'a', label: 'A light plastic axe with a yellow handle.', isCorrect: false, feedback: 'Incorrect. Plastics did not form his tool; it was heavy metal.' },
          { value: 'b', label: 'An old, heavy iron axe with a cracked wooden handle.', isCorrect: true, feedback: 'Congratulations! The text states he owned an old heavy iron axe with a cracked wooden handle.' },
          { value: 'c', label: 'A carbon fiber axe with a glowing laser core.', isCorrect: false, feedback: 'Incorrect. This might be modern times, but he carried a simple heavy iron axe.' },
          { value: 'd', label: 'A shining silver axe with gold leaf details.', isCorrect: false, feedback: 'Incorrect. That is the precious axe that the goddess offered him as a test.' }
        ]
      },
      {
        id: 'w-while-4',
        type: 'vocab-context',
        skill: 'VOCABULARY',
        title: 'Vocabulary in Context: Worthy of Honor',
        question: 'Which word in the text means "to be worthy of receiving something because of your good behavior or character"?',
        instruction: 'Click on the matching word from the snippet.',
        points: 4,
        passage: 'You chose truth over luxury. You deserve a reward!',
        correctWord: 'deserve',
        options: ['chose', 'truth', 'deserve', 'reward']
      },
      {
        id: 'w-while-5',
        type: 'fill-in-blank',
        skill: 'VOCABULARY',
        title: 'Vocabulary Mastery: Truth vs. Jealousy',
        instruction: 'Complete the blanks with the correct words based on characters\' moral choices.',
        points: 4,
        textWithBlanks: 'Arman was incredibly [blank1]. He would never lie to get things he did not [blank2]. However, his neighbor was [blank3], filled with jealousy. The goddess refused to grant any [blank4] to a liar.',
        blanks: [
          { key: 'blank1', correctAnswer: 'honest', options: ['honest', 'greedy', 'rich', 'careless'] },
          { key: 'blank2', correctAnswer: 'deserve', options: ['deserve', 'buy', 'steal', 'drop'] },
          { key: 'blank3', correctAnswer: 'greedy', options: ['greedy', 'kind', 'honest', 'poor'] },
          { key: 'blank4', correctAnswer: 'reward', options: ['reward', 'sorrow', 'axe', 'water'] }
        ]
      },
      {
        id: 'w-while-6',
        type: 'grammar-mc',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Grammar in Action: Adjectives of Quality',
        question: 'What type of adjectives are "golden", "silver", and "iron" as used in Section 3?',
        instruction: 'Select the class of adjectives.',
        points: 4,
        options: [
          { value: 'a', label: 'Adjectives of comparison (comparative/superlative)', isCorrect: false, feedback: 'Incorrect. These are not comparative forms.' },
          { value: 'b', label: 'Classifying adjectives indicating the material of composition', isCorrect: true, feedback: 'Perfect! They describe what material the axes are made of.' },
          { value: 'c', label: 'Adjectives of quantitive scale (numbers)', isCorrect: false, feedback: 'Incorrect. They describe materials, not numbers.' },
          { value: 'd', label: 'Possessive adjectives indicating ownership', isCorrect: false, feedback: 'Incorrect. "My" or "His" is possessive, not "golden".' }
        ]
      }
    ],
    postReadingTasks: [
      {
        id: 'w-post-1',
        type: 'inference-mc',
        skill: 'INFERENCE',
        title: 'Deep Conclusion: Goddess\'s Judgment',
        question: 'Why did the goddess vanish when Murat said the golden axe was his? What did she judge?',
        instruction: 'Examine her response in Section 4.',
        points: 4,
        options: [
          { value: 'a', label: 'She had to run to make dinner under the river.', isCorrect: false, feedback: 'Incorrect. No such cooking reference exists.' },
          { value: 'b', label: 'She recognized his lies immediate and punished his dishonesty and greed.', isCorrect: true, feedback: 'Splendid! She saw right through his lies, stating "You are dishonest and greedy," denying him any axes.' },
          { value: 'c', label: 'She was scared that Murat would hit her with his iron axe.', isCorrect: false, feedback: 'Incorrect. The iron axe was already sunk, and she holds magical powers.' }
        ]
      },
      {
        id: 'w-post-2',
        type: 'moral-mc',
        skill: 'INFERENCE',
        title: 'Moral Focus: Truth Pays Off',
        question: 'What does this folktale teach us about the long-term outcomes of honesty vs dishonesty?',
        instruction: 'Select the primary wisdom of this story.',
        points: 4,
        options: [
          { value: 'a', label: 'Lying is a quick and effective way to gain gold axes without work.', isCorrect: false, feedback: 'Incorrect. Murat lied and lost everything.' },
          { value: 'b', label: 'Honest actions bring trust and true rewards in life, while greed can lead to losing what you already have.', isCorrect: true, feedback: 'Perfect! Sincere honesty earned Arman a secure rich reward; Murat\'s lie left him with nothing.' },
          { value: 'c', label: 'Always chop trees near dry land so you do not have to talk to river spirits.', isCorrect: false, feedback: 'Incorrect. This might be a practical tip, but it is not the moral of the fable.' }
        ]
      },
      {
        id: 'w-post-3',
        type: 'mind-map',
        skill: 'DETAIL_RETRIEVAL',
        title: 'Mind Map: Integrity vs Greed',
        instruction: 'Select exactly 3 values representing Arman\'s integrity.',
        points: 4,
        characterName: 'Arman',
        traits: [
          { trait: 'Honest & Sincere', isCorrect: true, description: 'He confessed his tool was rusty iron and rejected luxury.' },
          { trait: 'Arrogant & Proud', isCorrect: false, description: 'He wept humbly on the rocks, hoping only for his family\'s bread.' },
          { trait: 'Humble & Hardworking', isCorrect: true, description: 'He cut firewood daily near Almaty to make direct honest coins.' },
          { trait: 'Jealous & Plotting', isCorrect: false, description: 'He had no jealousy; his neighbor Murat had.' },
          { trait: 'Content / Truthful', isCorrect: true, description: 'He asked only for his rusty axe and gained peace.' },
          { trait: 'Trickster / Lazy', isCorrect: false, description: 'He worked hard and sweaty under the morning sun.' }
        ],
        requiredCount: 3
      },
      {
        id: 'w-post-4',
        type: 'retelling',
        skill: 'SEQUENCING',
        title: 'Story Summary: Retelling Almaty\'s Woods',
        instruction: 'Order the chronological blocks to sum up the modern woodcutter.',
        points: 4,
        items: [
          { id: 'wret1', text: 'Arman, an honest woodcutter in Almaty, accidentally drops his iron axe in a river.', correctOrder: 0 },
          { id: 'wret2', text: 'A water goddess tests him by offering golden and silver blades.', correctOrder: 1 },
          { id: 'wret3', text: 'Arman truthfully rejects them, asking only for his own rusty iron tool.', correctOrder: 2 },
          { id: 'wret4', text: 'Impressed, the goddess rewards his absolute truth with all three axes.', correctOrder: 3 },
          { id: 'wret5', text: 'His jealous neighbor Murat tries to lie to the goddess and loses his own axe.', correctOrder: 4 }
        ]
      },
      {
        id: 'w-post-5',
        type: 'creative-text',
        skill: 'INFERENCE',
        title: 'Creative Project: Modern Moral Advice',
        instruction: 'Write 2 sentences of advice to the neighbor Murat on how he can improve his character and earn honest respect in his valley.',
        points: 4,
        placeholder: 'Murat, you should understand that honesty is...',
        minWords: 10
      }
    ]
  }
];
